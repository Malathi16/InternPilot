import { useState, useCallback } from 'react';
import { Sidebar, type Page } from '@/components/Sidebar';
import { Dashboard } from '@/pages/Dashboard';
import { Interns } from '@/pages/Interns';
import { Assignments } from '@/pages/Assignments';
import { Timeline } from '@/pages/Timeline';
import { Submissions } from '@/pages/Submissions';
import { Analytics } from '@/pages/Analytics';
import { Messages } from '@/pages/Messages';
import { useInterns, useAssignments, useSubmissions, useMessages } from '@/lib/hooks';
import { useRole, getActiveInternId, setActiveInternId } from '@/lib/role';
import type { Intern, Assignment } from '@/lib/types';

function App() {
  const [page, setPage] = useState<Page>('dashboard');
  const [role, setRole] = useRole();
  const [activeInternId, setActiveId] = useState<string | null>(getActiveInternId());

  const { interns, loading: iLoading, reload: iReload } = useInterns();
  const { assignments, loading: aLoading, reload: aReload } = useAssignments();
  const { submissions, loading: sLoading, reload: sReload } = useSubmissions();
  const { messages, loading: mLoading, reload: mReload } = useMessages();

  const loading = iLoading || aLoading || sLoading;

  const handleRoleChange = useCallback((r: typeof role) => {
    setRole(r);
    if (r !== 'intern') {
      setActiveInternId(null);
      setActiveId(null);
    } else if (!activeInternId && interns.length > 0) {
      const first = interns.find((i) => i.is_active) ?? interns[0];
      setActiveInternId(first.id);
      setActiveId(first.id);
    }
  }, [role, setRole, activeInternId, interns]);

  const viewAsIntern = useCallback((intern: Intern) => {
    setRole('intern');
    setActiveInternId(intern.id);
    setActiveId(intern.id);
    setPage('dashboard');
  }, [setRole]);

  const activeIntern = interns.find((i) => i.id === activeInternId) ?? null;
  const activeInternName = activeIntern?.full_name ?? null;

  const reloadAll = useCallback(() => { iReload(); aReload(); sReload(); mReload(); }, [iReload, aReload, sReload, mReload]);

  const goToAssignment = useCallback((a: Assignment) => {
    setPage('assignments');
  }, []);

  return (
    <div className="flex h-screen overflow-hidden bg-slate-50">
      <Sidebar page={page} setPage={setPage} role={role} setRole={handleRoleChange} activeInternName={activeInternName} />
      <main className="flex-1 overflow-y-auto">
        <div className="mx-auto max-w-7xl px-6 py-8">
          {page === 'dashboard' && (
            <Dashboard interns={interns} assignments={assignments} submissions={submissions} loading={loading} role={role} activeInternId={activeInternId} goTo={setPage} reload={reloadAll} />
          )}
          {page === 'interns' && role !== 'intern' && (
            <Interns interns={interns} submissions={submissions} assignments={assignments} loading={iLoading} role={role} reload={reloadAll} onRoleIntern={viewAsIntern} />
          )}
          {page === 'assignments' && (
            <Assignments assignments={assignments} interns={interns} loading={aLoading} role={role} reload={aReload} />
          )}
          {page === 'timeline' && (
            <Timeline assignments={assignments} submissions={submissions} interns={interns} loading={loading} role={role} activeInternId={activeInternId} onSelectAssignment={goToAssignment} />
          )}
          {page === 'submissions' && (
            <Submissions submissions={submissions} assignments={assignments} interns={interns} loading={sLoading} role={role} activeInternId={activeInternId} reload={sReload} goToAssignment={goToAssignment} />
          )}
          {page === 'analytics' && role !== 'intern' && (
            <Analytics interns={interns} assignments={assignments} submissions={submissions} loading={loading} />
          )}
          {page === 'messages' && (
            <Messages messages={messages} interns={interns} loading={mLoading} role={role} activeInternId={activeInternId} reload={mReload} />
          )}
          {page === 'interns' && role === 'intern' && (
            <div className="flex h-full items-center justify-center text-slate-400">This page is available to administrators and mentors only.</div>
          )}
        </div>
      </main>
    </div>
  );
}

export default App;
