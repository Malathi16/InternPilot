import { LayoutDashboard, Users, ClipboardList, CalendarDays, FileUp, GraduationCap, Shield, UserCog, BookOpen, BarChart3, Mail } from 'lucide-react';
import type { Role } from '@/lib/types';

export type Page = 'dashboard' | 'interns' | 'assignments' | 'timeline' | 'submissions' | 'analytics' | 'messages';

interface SidebarProps {
  page: Page;
  setPage: (p: Page) => void;
  role: Role;
  setRole: (r: Role) => void;
  activeInternName: string | null;
}

const NAV: { id: Page; label: string; icon: typeof Users; roles: Role[] }[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, roles: ['admin', 'mentor', 'intern'] },
  { id: 'interns', label: 'Interns', icon: Users, roles: ['admin', 'mentor'] },
  { id: 'assignments', label: 'Assignments', icon: ClipboardList, roles: ['admin', 'mentor', 'intern'] },
  { id: 'timeline', label: 'Day-by-Day', icon: CalendarDays, roles: ['admin', 'mentor', 'intern'] },
  { id: 'submissions', label: 'Submissions', icon: FileUp, roles: ['admin', 'mentor', 'intern'] },
  { id: 'analytics', label: 'Analytics', icon: BarChart3, roles: ['admin', 'mentor'] },
  { id: 'messages', label: 'Messages', icon: Mail, roles: ['admin', 'mentor', 'intern'] },
];

const ROLE_LABELS: Record<Role, { label: string; icon: typeof Shield; color: string }> = {
  admin: { label: 'Administrator', icon: Shield, color: 'text-rose-600' },
  mentor: { label: 'Mentor', icon: UserCog, color: 'text-amber-600' },
  intern: { label: 'Intern', icon: BookOpen, color: 'text-emerald-600' },
};

export function Sidebar({ page, setPage, role, setRole, activeInternName }: SidebarProps) {
  const items = NAV.filter((n) => n.roles.includes(role));
  const roleInfo = ROLE_LABELS[role];
  const RoleIcon = roleInfo.icon;

  return (
    <aside className="flex h-screen w-64 flex-shrink-0 flex-col border-r border-slate-200 bg-white">
      <div className="flex items-center gap-2.5 px-5 py-5 border-b border-slate-100">
        <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-slate-900 text-white">
          <GraduationCap className="h-5 w-5" />
        </div>
        <div>
          <p className="text-sm font-bold text-slate-900 leading-tight">InternPilot</p>
          <p className="text-[11px] text-slate-500 leading-tight">AI Intern Management</p>
        </div>
      </div>

      <nav className="flex-1 space-y-0.5 px-3 py-4 overflow-y-auto">
        {items.map((item) => {
          const Icon = item.icon;
          const active = page === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setPage(item.id)}
              className={`flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-all ${
                active
                  ? 'bg-slate-900 text-white shadow-sm'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              <Icon className="h-[18px] w-[18px] flex-shrink-0" />
              {item.label}
            </button>
          );
        })}
      </nav>

      <div className="border-t border-slate-100 px-3 py-4 space-y-3">
        {role === 'intern' && activeInternName && (
          <div className="rounded-lg bg-slate-50 px-3 py-2">
            <p className="text-[11px] font-medium uppercase tracking-wide text-slate-400">Viewing as</p>
            <p className="text-sm font-medium text-slate-700 truncate">{activeInternName}</p>
          </div>
        )}
        <div>
          <p className="mb-1.5 px-1 text-[11px] font-medium uppercase tracking-wide text-slate-400">Role</p>
          <div className="grid grid-cols-3 gap-1">
            {(['admin', 'mentor', 'intern'] as Role[]).map((r) => {
              const info = ROLE_LABELS[r];
              const Icon = info.icon;
              return (
                <button
                  key={r}
                  onClick={() => setRole(r)}
                  className={`flex flex-col items-center gap-1 rounded-lg px-1 py-2 text-[11px] font-medium transition-all ${
                    role === r
                      ? 'bg-slate-900 text-white'
                      : 'bg-slate-50 text-slate-500 hover:bg-slate-100'
                  }`}
                  title={info.label}
                >
                  <Icon className="h-4 w-4" />
                  <span className="capitalize">{r}</span>
                </button>
              );
            })}
          </div>
        </div>
        <div className={`flex items-center gap-2 rounded-lg bg-slate-50 px-3 py-2 ${roleInfo.color}`}>
          <RoleIcon className="h-4 w-4" />
          <span className="text-xs font-medium">{roleInfo.label}</span>
        </div>
      </div>
    </aside>
  );
}
