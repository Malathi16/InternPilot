export type InternStatus = 'Active' | 'On Hold' | 'Completed' | 'Terminated';

export interface Intern {
  id: string;
  full_name: string;
  email: string;
  phone: string | null;
  photo_url: string | null;
  intern_id: string;
  department: string;
  role: string;
  project: string | null;
  mentor: string | null;
  supervisor: string | null;
  start_date: string;
  end_date: string | null;
  status: InternStatus;
  skills: string[];
  learning_goals: string | null;
  notes: string | null;
  is_active: boolean;
  created_at: string;
}

export type AssignmentStatus = 'draft' | 'published' | 'archived' | 'cancelled';
export type TargetType = 'individual' | 'group' | 'batch';
export type Priority = 'Low' | 'Medium' | 'High';

export interface Assignment {
  id: string;
  title: string;
  description: string | null;
  day_number: number;
  instructions: string | null;
  learning_objectives: string | null;
  expected_outcome: string | null;
  assignment_date: string;
  due_date: string | null;
  priority: Priority;
  estimated_time_minutes: number | null;
  attachment_urls: string[];
  permitted_formats: string[];
  max_file_size_mb: number;
  max_file_count: number;
  evaluation_criteria: string | null;
  rubric: string | null;
  acceptance_criteria: string | null;
  status: AssignmentStatus;
  target_type: TargetType;
  target_intern_ids: string[];
  created_at: string;
}

export type SubmissionStatus =
  | 'Not Started'
  | 'In Progress'
  | 'Submitted'
  | 'Under Review'
  | 'Changes Requested'
  | 'Resubmitted'
  | 'Approved'
  | 'Overdue';

export interface Submission {
  id: string;
  intern_id: string;
  assignment_id: string;
  version: number;
  file_names: string[];
  storage_paths: string[];
  repo_url: string | null;
  deployed_url: string | null;
  notes: string | null;
  status: SubmissionStatus;
  mentor_feedback: string | null;
  score: number | null;
  resubmission_reason: string | null;
  submitted_at: string | null;
  created_at: string;
}

export interface AuditLog {
  id: string;
  intern_id: string | null;
  action: string;
  details: string | null;
  actor: string | null;
  created_at: string;
}

export type Role = 'admin' | 'mentor' | 'intern';

export interface Message {
  id: string;
  from_role: 'admin' | 'mentor';
  from_name: string;
  to_intern_id: string | null;
  to_department: string | null;
  subject: string;
  body: string;
  priority: 'Low' | 'Medium' | 'High';
  read_at: string | null;
  created_at: string;
}

export interface MessageInput {
  from_role: 'admin' | 'mentor';
  from_name: string;
  to_intern_id: string | null;
  to_department: string | null;
  subject: string;
  body: string;
  priority: 'Low' | 'Medium' | 'High';
}

export interface InternInput {
  full_name: string;
  email: string;
  phone?: string | null;
  photo_url?: string | null;
  intern_id: string;
  department: string;
  role: string;
  project?: string | null;
  mentor?: string | null;
  supervisor?: string | null;
  start_date: string;
  end_date?: string | null;
  status: InternStatus;
  skills: string[];
  learning_goals?: string | null;
  notes?: string | null;
}

export interface AssignmentInput {
  title: string;
  description?: string | null;
  day_number: number;
  instructions?: string | null;
  learning_objectives?: string | null;
  expected_outcome?: string | null;
  assignment_date: string;
  due_date?: string | null;
  priority: Priority;
  estimated_time_minutes?: number | null;
  attachment_urls: string[];
  permitted_formats: string[];
  max_file_size_mb: number;
  max_file_count: number;
  evaluation_criteria?: string | null;
  rubric?: string | null;
  acceptance_criteria?: string | null;
  status: AssignmentStatus;
  target_type: TargetType;
  target_intern_ids: string[];
}
