import { useState, useCallback } from 'react';
import type { Role } from './types';

const KEY = 'internpilot_role';
const INTERN_KEY = 'internpilot_active_intern';

export function useRole(): [Role, (r: Role) => void] {
  const [role, setRole] = useState<Role>(() => {
    return (localStorage.getItem(KEY) as Role) || 'admin';
  });

  const change = useCallback((r: Role) => {
    setRole(r);
    localStorage.setItem(KEY, r);
  }, []);

  return [role, change];
}

export function getActiveInternId(): string | null {
  return localStorage.getItem(INTERN_KEY);
}

export function setActiveInternId(id: string | null) {
  if (id) localStorage.setItem(INTERN_KEY, id);
  else localStorage.removeItem(INTERN_KEY);
}
