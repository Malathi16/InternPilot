import type { InternStatus, SubmissionStatus, Priority, AssignmentStatus } from './types';

export const INTERN_STATUSES: InternStatus[] = ['Active', 'On Hold', 'Completed', 'Terminated'];

export const SUBMISSION_STATUSES: SubmissionStatus[] = [
  'Not Started',
  'In Progress',
  'Submitted',
  'Under Review',
  'Changes Requested',
  'Resubmitted',
  'Approved',
  'Overdue',
];

export const PRIORITIES: Priority[] = ['Low', 'Medium', 'High'];

export const ASSIGNMENT_STATUSES: AssignmentStatus[] = ['draft', 'published', 'archived', 'cancelled'];

export const DEPARTMENTS = ['Engineering', 'Data Science', 'Design', 'Marketing', 'Product', 'Operations'];

export const STATUS_STYLES: Record<InternStatus, string> = {
  Active: 'bg-emerald-50 text-emerald-700 ring-emerald-600/20',
  'On Hold': 'bg-amber-50 text-amber-700 ring-amber-600/20',
  Completed: 'bg-blue-50 text-blue-700 ring-blue-600/20',
  Terminated: 'bg-rose-50 text-rose-700 ring-rose-600/20',
};

export const SUBMISSION_STATUS_STYLES: Record<SubmissionStatus, string> = {
  'Not Started': 'bg-slate-100 text-slate-600 ring-slate-500/20',
  'In Progress': 'bg-sky-50 text-sky-700 ring-sky-600/20',
  Submitted: 'bg-indigo-50 text-indigo-700 ring-indigo-600/20',
  'Under Review': 'bg-violet-50 text-violet-700 ring-violet-600/20',
  'Changes Requested': 'bg-orange-50 text-orange-700 ring-orange-600/20',
  Resubmitted: 'bg-cyan-50 text-cyan-700 ring-cyan-600/20',
  Approved: 'bg-emerald-50 text-emerald-700 ring-emerald-600/20',
  Overdue: 'bg-rose-50 text-rose-700 ring-rose-600/20',
};

export const PRIORITY_STYLES: Record<Priority, string> = {
  Low: 'bg-slate-100 text-slate-600 ring-slate-500/20',
  Medium: 'bg-amber-50 text-amber-700 ring-amber-600/20',
  High: 'bg-rose-50 text-rose-700 ring-rose-600/20',
};

export const PROGRAM_DAYS = 30;
