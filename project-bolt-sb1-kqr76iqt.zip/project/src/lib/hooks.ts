import { useEffect, useState } from 'react';
import type { Intern, Assignment, Submission, AuditLog, Message } from './types';
import { supabase } from './supabase';

export function useInterns() {
  const [interns, setInterns] = useState<Intern[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('interns')
      .select('*')
      .order('created_at', { ascending: false });
    if (error) setError(error.message);
    else setInterns(data as Intern[]);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);
  return { interns, loading, error, reload: load };
}

export function useAssignments() {
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('assignments')
      .select('*')
      .order('day_number', { ascending: true });
    if (error) setError(error.message);
    else setAssignments(data as Assignment[]);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);
  return { assignments, loading, error, reload: load };
}

export function useSubmissions() {
  const [submissions, setSubmissions] = useState<Submission[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('submissions')
      .select('*')
      .order('created_at', { ascending: false });
    if (error) setError(error.message);
    else setSubmissions(data as Submission[]);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);
  return { submissions, loading, error, reload: load };
}

export function useMessages() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('messages')
      .select('*')
      .order('created_at', { ascending: false });
    if (error) setError(error.message);
    else setMessages(data as Message[]);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);
  return { messages, loading, error, reload: load };
}

export function useAuditLog(internId?: string) {
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let query = supabase.from('audit_log').select('*').order('created_at', { ascending: false });
    if (internId) query = query.eq('intern_id', internId);
    query.then(({ data }) => {
      setLogs((data as AuditLog[]) ?? []);
      setLoading(false);
    });
  }, [internId]);

  return { logs, loading };
}
