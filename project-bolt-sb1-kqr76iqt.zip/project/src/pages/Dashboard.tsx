import { useState } from 'react';
import { supabase } from '@/lib/supabase';
import { Users, ClipboardList, FileUp, CheckCircle2, Clock, AlertTriangle, TrendingUp, Calendar, Plus, UserPlus } from 'lucide-react';
import type { Intern, Assignment, Submission, InternStatus, InternInput } from '@/lib/types';
import { Badge, Button, Card, EmptyState, Input, Modal, Select, Spinner, Textarea } from '@/components/ui';
import { STATUS_STYLES, SUBMISSION_STATUS_STYLES, INTERN_STATUSES, DEPARTMENTS } from '@/lib/constants';

interface DashboardProps {
  interns: Intern[];
  assignments: Assignment[];
  submissions: Submission[];
  loading: boolean;
  role: string;
  activeInternId: string | null;
  goTo: (page: 'interns' | 'assignments' | 'timeline' | 'submissions') => void;
  reload: () => void;
}

const emptyStudent: InternInput = {
  full_name: '', email: '', phone: '', intern_id: '', department: 'Engineering',
  role: '', project: '', mentor: '', supervisor: '', start_date: new Date().toISOString().slice(0, 10),
  end_date: '', status: 'Active', skills: [], learning_goals: '', notes: '',
};

export function Dashboard({ interns, assignments, submissions, loading, role, activeInternId, goTo, reload }: DashboardProps) {
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState<InternInput>(emptyStudent);
  const [skillsInput, setSkillsInput] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const canManage = role === 'admin' || role === 'mentor';

  const openAdd = () => {
    setForm(emptyStudent);
    setSkillsInput('');
    setError(null);
    setShowAdd(true);
  };

  const save = async () => {
    setSaving(true);
    setError(null);
    const skills = skillsInput.split(',').map((s) => s.trim()).filter(Boolean);
    const payload = {
      ...form,
      skills,
      end_date: form.end_date || null,
      phone: form.phone || null,
      project: form.project || null,
      mentor: form.mentor || null,
      supervisor: form.supervisor || null,
      learning_goals: form.learning_goals || null,
      notes: form.notes || null,
    };
    const { error: e } = await supabase.from('interns').insert(payload);
    if (e) {
      setError(e.message);
      setSaving(false);
      return;
    }
    await supabase.from('audit_log').insert({
      intern_id: null,
      action: 'Created',
      details: `Intern ${form.full_name} (${form.intern_id}) added from Dashboard.`,
      actor: role.charAt(0).toUpperCase() + role.slice(1),
    });
    setSaving(false);
    setShowAdd(false);
    setSuccess(`${form.full_name} was added successfully.`);
    setTimeout(() => setSuccess(null), 4000);
    reload();
  };

  if (loading) return <Spinner className="py-20" />;

  const activeInterns = interns.filter((i) => i.status === 'Active');
  const publishedAssignments = assignments.filter((a) => a.status === 'published');
  const approvedSubs = submissions.filter((s) => s.status === 'Approved');
  const pendingReview = submissions.filter((s) => s.status === 'Under Review' || s.status === 'Submitted');
  const overdueSubs = submissions.filter((s) => s.status === 'Overdue');

  const myIntern = role === 'intern' ? interns.find((i) => i.id === activeInternId) : null;
  const mySubs = role === 'intern' ? submissions.filter((s) => s.intern_id === activeInternId) : [];
  const myApproved = mySubs.filter((s) => s.status === 'Approved').length;
  const myTotal = mySubs.length;
  const myProgress = myTotal > 0 ? Math.round((myApproved / myTotal) * 100) : 0;

  const stats = role === 'intern'
    ? [
        { label: 'My Assignments', value: myTotal, icon: ClipboardList, color: 'bg-sky-50 text-sky-600' },
        { label: 'Approved', value: myApproved, icon: CheckCircle2, color: 'bg-emerald-50 text-emerald-600' },
        { label: 'In Progress', value: mySubs.filter((s) => s.status === 'In Progress').length, icon: Clock, color: 'bg-amber-50 text-amber-600' },
        { label: 'Completion', value: `${myProgress}%`, icon: TrendingUp, color: 'bg-violet-50 text-violet-600' },
      ]
    : [
        { label: 'Active Students', value: activeInterns.length, icon: Users, color: 'bg-sky-50 text-sky-600' },
        { label: 'Assignments', value: publishedAssignments.length, icon: ClipboardList, color: 'bg-violet-50 text-violet-600' },
        { label: 'Pending Review', value: pendingReview.length, icon: Clock, color: 'bg-amber-50 text-amber-600' },
        { label: 'Overdue', value: overdueSubs.length, icon: AlertTriangle, color: 'bg-rose-50 text-rose-600' },
      ];

  const recentSubs = [...submissions]
    .sort((a, b) => (b.submitted_at ?? b.created_at).localeCompare(a.submitted_at ?? a.created_at))
    .slice(0, 6);

  const internMap = new Map(interns.map((i) => [i.id, i]));
  const assignmentMap = new Map(assignments.map((a) => [a.id, a]));

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">Dashboard</h1>
          <p className="mt-1 text-sm text-slate-500">
            {role === 'intern'
              ? `Welcome back, ${myIntern?.full_name ?? 'Intern'}. Here is your internship at a glance.`
              : 'Overview of your internship program, students, and assignments.'}
          </p>
        </div>
        {canManage && (
          <Button onClick={openAdd}><UserPlus className="h-4 w-4" /> Add Student</Button>
        )}
      </div>

      {success && (
        <div className="flex items-center gap-2 rounded-lg bg-emerald-50 px-4 py-3 text-sm font-medium text-emerald-700 ring-1 ring-emerald-200">
          <CheckCircle2 className="h-4 w-4" /> {success}
        </div>
      )}

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {stats.map((s) => {
          const Icon = s.icon;
          return (
            <Card key={s.label} className="p-5">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-500">{s.label}</p>
                  <p className="mt-1 text-3xl font-bold tracking-tight text-slate-900">{s.value}</p>
                </div>
                <div className={`flex h-11 w-11 items-center justify-center rounded-xl ${s.color}`}>
                  <Icon className="h-5 w-5" />
                </div>
              </div>
            </Card>
          );
        })}
      </div>

      {role === 'intern' && myIntern && (
        <Card className="p-5">
          <div className="flex items-center gap-4">
            {myIntern.photo_url ? (
              <img src={myIntern.photo_url} alt="" className="h-16 w-16 rounded-full object-cover ring-2 ring-slate-200" />
            ) : (
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-slate-900 text-xl font-bold text-white">
                {myIntern.full_name.split(' ').map((n) => n[0]).join('').slice(0, 2)}
              </div>
            )}
            <div className="flex-1">
              <h2 className="text-lg font-semibold text-slate-900">{myIntern.full_name}</h2>
              <p className="text-sm text-slate-500">{myIntern.role} · {myIntern.department}</p>
              <div className="mt-2 flex items-center gap-2">
                <Badge className={STATUS_STYLES[myIntern.status]}>{myIntern.status}</Badge>
                <span className="text-xs text-slate-400">{myIntern.intern_id}</span>
              </div>
            </div>
            <div className="hidden sm:block">
              <div className="flex items-center gap-2 text-sm text-slate-500">
                <Calendar className="h-4 w-4" />
                <span>Started {new Date(myIntern.start_date).toLocaleDateString()}</span>
              </div>
            </div>
          </div>
          {myIntern.skills.length > 0 && (
            <div className="mt-4 flex flex-wrap gap-1.5">
              {myIntern.skills.map((sk) => (
                <span key={sk} className="rounded-md bg-slate-100 px-2 py-0.5 text-xs font-medium text-slate-600">{sk}</span>
              ))}
            </div>
          )}
        </Card>
      )}

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2 p-5">
          <div className="mb-4 flex items-center justify-between">
            <h3 className="text-base font-semibold text-slate-900">Recent Submissions</h3>
            <button onClick={() => goTo('submissions')} className="text-sm font-medium text-slate-500 hover:text-slate-900">View all →</button>
          </div>
          {recentSubs.length === 0 ? (
            <EmptyState icon={<FileUp className="h-6 w-6" />} title="No submissions yet" subtitle="Submissions will appear here once students start submitting." />
          ) : (
            <div className="space-y-2">
              {recentSubs.map((s) => {
                const intern = internMap.get(s.intern_id);
                const assignment = assignmentMap.get(s.assignment_id);
                return (
                  <div key={s.id} className="flex items-center gap-3 rounded-lg border border-slate-100 px-3 py-2.5 hover:bg-slate-50 transition">
                    <div className="flex h-9 w-9 items-center justify-center rounded-full bg-slate-100 text-xs font-semibold text-slate-600">
                      {(intern?.full_name ?? '?').split(' ').map((n) => n[0]).join('').slice(0, 2)}
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium text-slate-900">{assignment?.title ?? 'Unknown assignment'}</p>
                      <p className="truncate text-xs text-slate-500">{intern?.full_name ?? 'Unknown'} · v{s.version}</p>
                    </div>
                    <Badge className={SUBMISSION_STATUS_STYLES[s.status]}>{s.status}</Badge>
                  </div>
                );
              })}
            </div>
          )}
        </Card>

        <Card className="p-5">
          <h3 className="mb-4 text-base font-semibold text-slate-900">Program Progress</h3>
          <div className="space-y-4">
            {[
              { label: 'Active Students', count: activeInterns.length, total: interns.length, color: 'bg-sky-500' },
              { label: 'Approved Submissions', count: approvedSubs.length, total: submissions.length, color: 'bg-emerald-500' },
              { label: 'Published Assignments', count: publishedAssignments.length, total: assignments.length, color: 'bg-violet-500' },
            ].map((p) => (
              <div key={p.label}>
                <div className="mb-1.5 flex items-center justify-between text-sm">
                  <span className="text-slate-600">{p.label}</span>
                  <span className="font-medium text-slate-900">{p.count}/{p.total}</span>
                </div>
                <div className="h-2 overflow-hidden rounded-full bg-slate-100">
                  <div className={`h-full rounded-full ${p.color} transition-all duration-500`} style={{ width: `${p.total > 0 ? (p.count / p.total) * 100 : 0}%` }} />
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <Modal open={showAdd} onClose={() => setShowAdd(false)} title="Add Student" size="lg">
        <div className="space-y-4">
          {error && <div className="rounded-lg bg-rose-50 px-4 py-3 text-sm text-rose-700 ring-1 ring-rose-200">{error}</div>}
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <Input label="Full Name" value={form.full_name} onChange={(v) => setForm({ ...form, full_name: v })} required />
            <Input label="Student / Intern ID" value={form.intern_id} onChange={(v) => setForm({ ...form, intern_id: v })} placeholder="IP-2026-001" required />
            <Input label="Email" type="email" value={form.email} onChange={(v) => setForm({ ...form, email: v })} required />
            <Input label="Phone" value={form.phone ?? ''} onChange={(v) => setForm({ ...form, phone: v })} placeholder="+91 ..." />
            <Select label="Department" value={form.department} onChange={(v) => setForm({ ...form, department: v })} options={DEPARTMENTS.map((d) => ({ value: d, label: d }))} required />
            <Input label="Internship Role" value={form.role} onChange={(v) => setForm({ ...form, role: v })} required />
            <Input label="Assigned Project" value={form.project ?? ''} onChange={(v) => setForm({ ...form, project: v })} />
            <Input label="Mentor" value={form.mentor ?? ''} onChange={(v) => setForm({ ...form, mentor: v })} />
            <Input label="Supervisor" value={form.supervisor ?? ''} onChange={(v) => setForm({ ...form, supervisor: v })} />
            <Select label="Status" value={form.status} onChange={(v) => setForm({ ...form, status: v as InternStatus })} options={INTERN_STATUSES.map((s) => ({ value: s, label: s }))} required />
            <Input label="Start Date" type="date" value={form.start_date} onChange={(v) => setForm({ ...form, start_date: v })} required />
            <Input label="End Date" type="date" value={form.end_date ?? ''} onChange={(v) => setForm({ ...form, end_date: v })} />
          </div>
          <Input label="Skills (comma-separated)" value={skillsInput} onChange={setSkillsInput} placeholder="React, TypeScript, ..." />
          <Textarea label="Learning Goals" value={form.learning_goals ?? ''} onChange={(v) => setForm({ ...form, learning_goals: v })} rows={2} />
          <Textarea label="Notes" value={form.notes ?? ''} onChange={(v) => setForm({ ...form, notes: v })} rows={2} />
          <div className="flex justify-end gap-2 border-t border-slate-100 pt-4">
            <Button variant="secondary" onClick={() => setShowAdd(false)}>Cancel</Button>
            <Button onClick={save} disabled={saving}>{saving ? 'Adding...' : 'Add Student'}</Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
