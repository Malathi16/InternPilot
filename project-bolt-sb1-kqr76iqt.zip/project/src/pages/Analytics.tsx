import { useMemo } from 'react';
import type { Intern, Assignment, Submission } from '@/lib/types';
import { Card, Spinner, EmptyState, Badge } from '@/components/ui';
import { SUBMISSION_STATUS_STYLES } from '@/lib/constants';
import { BarChart3, Star, Clock, Building2, TrendingUp, Users, Gauge, CheckCircle, Hourglass } from 'lucide-react';

interface AnalyticsProps {
  interns: Intern[];
  assignments: Assignment[];
  submissions: Submission[];
  loading: boolean;
}

interface MentorStat {
  mentor: string;
  count: number;
  avgTurnaroundHours: number;
  reviewed: number;
  pending: number;
}

interface DeptStat {
  department: string;
  count: number;
  avgScore: number;
  approved: number;
  total: number;
  approvalRate: number;
}

export function Analytics({ interns, assignments, submissions, loading }: AnalyticsProps) {
  const internMap = useMemo(() => new Map(interns.map((i) => [i.id, i])), [interns]);
  const assignmentMap = useMemo(() => new Map(assignments.map((a) => [a.id, a])), [assignments]);

  const scored = useMemo(() => submissions.filter((s) => s.score !== null), [submissions]);
  const overallAvg = useMemo(() => {
    if (scored.length === 0) return 0;
    return scored.reduce((sum, s) => sum + (s.score ?? 0), 0) / scored.length;
  }, [scored]);

  // Per-intern average scores
  const internScores = useMemo(() => {
    const map = new Map<string, { intern: Intern; scores: number[]; total: number; approved: number }>();
    submissions.forEach((s) => {
      const intern = internMap.get(s.intern_id);
      if (!intern) return;
      const entry = map.get(intern.id) ?? { intern, scores: [], total: 0, approved: 0 };
      entry.total++;
      if (s.score !== null) entry.scores.push(s.score);
      if (s.status === 'Approved') entry.approved++;
      map.set(intern.id, entry);
    });
    return Array.from(map.values())
      .map((e) => ({ ...e, avgScore: e.scores.length > 0 ? e.scores.reduce((a, b) => a + b, 0) / e.scores.length : 0 }))
      .sort((a, b) => b.avgScore - a.avgScore);
  }, [submissions, internMap]);

  // Mentor review turnaround: time from submission to score being set.
  // We approximate using submitted_at → created_at of the latest version where score exists.
  // Since we don't store review timestamp, we measure from submitted_at to now for pending,
  // and for scored submissions we use the gap between submitted_at and created_at of the scored version.
  const mentorStats = useMemo<MentorStat[]>(() => {
    const map = new Map<string, MentorStat>();
    submissions.forEach((s) => {
      const intern = internMap.get(s.intern_id);
      const mentor = intern?.mentor;
      if (!mentor) return;
      const entry = map.get(mentor) ?? { mentor, count: 0, avgTurnaroundHours: 0, reviewed: 0, pending: 0 };
      entry.count++;
      if (s.score !== null && s.status !== 'In Progress' && s.status !== 'Not Started') {
        entry.reviewed++;
        if (s.submitted_at) {
          const submitted = new Date(s.submitted_at).getTime();
          const reviewedAt = new Date(s.created_at).getTime();
          const hours = (reviewedAt - submitted) / (1000 * 60 * 60);
          if (hours >= 0) {
            entry.avgTurnaroundHours = (entry.avgTurnaroundHours * (entry.reviewed - 1) + hours) / entry.reviewed;
          }
        }
      } else if (s.status === 'Submitted' || s.status === 'Resubmitted' || s.status === 'Under Review') {
        entry.pending++;
      }
    });
    return Array.from(map.values()).sort((a, b) => b.count - a.count);
  }, [submissions, internMap]);

  const avgTurnaround = useMemo(() => {
    const reviewed = mentorStats.filter((m) => m.reviewed > 0);
    if (reviewed.length === 0) return 0;
    return reviewed.reduce((sum, m) => sum + m.avgTurnaroundHours, 0) / reviewed.length;
  }, [mentorStats]);

  // Department performance breakdown
  const deptStats = useMemo<DeptStat[]>(() => {
    const map = new Map<string, DeptStat>();
    submissions.forEach((s) => {
      const intern = internMap.get(s.intern_id);
      if (!intern) return;
      const entry = map.get(intern.department) ?? { department: intern.department, count: 0, avgScore: 0, approved: 0, total: 0, approvalRate: 0 };
      entry.total++;
      if (s.score !== null) {
        entry.count++;
        entry.avgScore = (entry.avgScore * (entry.count - 1) + (s.score ?? 0)) / entry.count;
      }
      if (s.status === 'Approved') entry.approved++;
      map.set(intern.department, entry);
    });
    return Array.from(map.values()).map((e) => ({ ...e, approvalRate: e.total > 0 ? Math.round((e.approved / e.total) * 100) : 0 }))
      .sort((a, b) => b.avgScore - a.avgScore);
  }, [submissions, internMap]);

  if (loading) return <Spinner className="py-20" />;

  const maxScore = 5;
  const maxTurnaround = Math.max(...mentorStats.map((m) => m.avgTurnaroundHours), 1);
  const maxDeptScore = Math.max(...deptStats.map((d) => d.avgScore), 1);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">Analytics</h1>
        <p className="mt-1 text-sm text-slate-500">Program performance insights across interns, mentors, and departments.</p>
      </div>

      {/* Summary stat cards */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <SummaryCard label="Avg Intern Score" value={overallAvg.toFixed(2)} suffix="/ 5" icon={Star} color="bg-amber-50 text-amber-600" />
        <SummaryCard label="Avg Review Turnaround" value={formatHours(avgTurnaround)} icon={Clock} color="bg-sky-50 text-sky-600" />
        <SummaryCard label="Reviewed Submissions" value={String(submissions.filter((s) => s.score !== null).length)} icon={CheckCircle} color="bg-emerald-50 text-emerald-600" />
        <SummaryCard label="Pending Reviews" value={String(submissions.filter((s) => s.status === 'Submitted' || s.status === 'Resubmitted' || s.status === 'Under Review').length)} icon={Hourglass} color="bg-rose-50 text-rose-600" />
      </div>

      {/* Intern score leaderboard */}
      <Card className="p-5">
        <div className="mb-4 flex items-center gap-2">
          <TrendingUp className="h-5 w-5 text-slate-400" />
          <h3 className="text-base font-semibold text-slate-900">Average Intern Scores</h3>
        </div>
        {internScores.length === 0 ? (
          <EmptyState icon={<Users className="h-6 w-6" />} title="No scored submissions yet" subtitle="Scores will appear here once mentors start reviewing." />
        ) : (
          <div className="space-y-3">
            {internScores.map((entry, idx) => (
              <div key={entry.intern.id} className="flex items-center gap-4">
                <div className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-slate-100 text-xs font-bold text-slate-600">{idx + 1}</div>
                <div className="min-w-0 flex-1">
                  <div className="mb-1 flex items-center justify-between gap-2">
                    <p className="truncate text-sm font-medium text-slate-900">{entry.intern.full_name}</p>
                    <div className="flex flex-shrink-0 items-center gap-2">
                      <span className="text-xs text-slate-400">{entry.approved}/{entry.total} approved</span>
                      <span className="flex items-center gap-1 text-sm font-bold text-slate-900"><Star className="h-3.5 w-3.5 text-amber-400" />{entry.avgScore.toFixed(1)}</span>
                    </div>
                  </div>
                  <div className="h-2 overflow-hidden rounded-full bg-slate-100">
                    <div className="h-full rounded-full bg-gradient-to-r from-amber-400 to-amber-500 transition-all duration-500" style={{ width: `${(entry.avgScore / maxScore) * 100}%` }} />
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* Mentor review turnaround */}
        <Card className="p-5">
          <div className="mb-4 flex items-center gap-2">
            <Clock className="h-5 w-5 text-slate-400" />
            <h3 className="text-base font-semibold text-slate-900">Mentor Review Turnaround</h3>
          </div>
          {mentorStats.length === 0 ? (
            <EmptyState icon={<Clock className="h-6 w-6" />} title="No mentor data yet" />
          ) : (
            <div className="space-y-3">
              {mentorStats.map((m) => (
                <div key={m.mentor} className="rounded-lg border border-slate-100 p-3">
                  <div className="mb-2 flex items-center justify-between">
                    <p className="text-sm font-medium text-slate-900">{m.mentor}</p>
                    <span className="text-xs text-slate-400">{m.reviewed} reviewed · {m.pending} pending</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="h-2 flex-1 overflow-hidden rounded-full bg-slate-100">
                      <div className="h-full rounded-full bg-sky-500 transition-all duration-500" style={{ width: `${(m.avgTurnaroundHours / maxTurnaround) * 100}%` }} />
                    </div>
                    <span className="flex-shrink-0 text-sm font-semibold text-slate-700">{formatHours(m.avgTurnaroundHours)}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>

        {/* Department performance breakdown */}
        <Card className="p-5">
          <div className="mb-4 flex items-center gap-2">
            <Building2 className="h-5 w-5 text-slate-400" />
            <h3 className="text-base font-semibold text-slate-900">Department Performance</h3>
          </div>
          {deptStats.length === 0 ? (
            <EmptyState icon={<Building2 className="h-6 w-6" />} title="No department data yet" />
          ) : (
            <div className="space-y-3">
              {deptStats.map((d) => (
                <div key={d.department} className="rounded-lg border border-slate-100 p-3">
                  <div className="mb-2 flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-slate-900">{d.department}</p>
                      <p className="text-xs text-slate-400">{d.total} submissions · {d.approved} approved</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className="bg-emerald-50 text-emerald-700 ring-emerald-600/20">{d.approvalRate}% approved</Badge>
                      <span className="flex items-center gap-1 text-sm font-bold text-slate-900"><Star className="h-3.5 w-3.5 text-amber-400" />{d.avgScore.toFixed(1)}</span>
                    </div>
                  </div>
                  <div className="h-2 overflow-hidden rounded-full bg-slate-100">
                    <div className="h-full rounded-full bg-gradient-to-r from-violet-400 to-violet-500 transition-all duration-500" style={{ width: `${(d.avgScore / maxDeptScore) * 100}%` }} />
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>

      {/* Submission status distribution */}
      <Card className="p-5">
        <div className="mb-4 flex items-center gap-2">
          <Gauge className="h-5 w-5 text-slate-400" />
          <h3 className="text-base font-semibold text-slate-900">Submission Status Distribution</h3>
        </div>
        <StatusDistribution submissions={submissions} />
      </Card>
    </div>
  );
}

function SummaryCard({ label, value, suffix, icon: Icon, color }: { label: string; value: string; suffix?: string; icon: typeof Star; color: string }) {
  return (
    <Card className="p-5">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-slate-500">{label}</p>
          <p className="mt-1 text-3xl font-bold tracking-tight text-slate-900">
            {value}{suffix && <span className="ml-1 text-base font-medium text-slate-400">{suffix}</span>}
          </p>
        </div>
        <div className={`flex h-11 w-11 items-center justify-center rounded-xl ${color}`}>
          <Icon className="h-5 w-5" />
        </div>
      </div>
    </Card>
  );
}

function StatusDistribution({ submissions }: { submissions: Submission[] }) {
  const counts = useMemo(() => {
    const map = new Map<string, number>();
    submissions.forEach((s) => map.set(s.status, (map.get(s.status) ?? 0) + 1));
    return Array.from(map.entries()).sort((a, b) => b[1] - a[1]);
  }, [submissions]);

  if (submissions.length === 0) return <EmptyState icon={<BarChart3 className="h-6 w-6" />} title="No submissions to analyze" />;
  const total = submissions.length;

  return (
    <div className="space-y-2">
      {counts.map(([status, count]) => (
        <div key={status} className="flex items-center gap-3">
          <div className="w-32 flex-shrink-0"><Badge className={SUBMISSION_STATUS_STYLES[status as keyof typeof SUBMISSION_STATUS_STYLES]}>{status}</Badge></div>
          <div className="h-2 flex-1 overflow-hidden rounded-full bg-slate-100">
            <div className="h-full rounded-full bg-slate-700 transition-all duration-500" style={{ width: `${(count / total) * 100}%` }} />
          </div>
          <span className="w-12 flex-shrink-0 text-right text-sm font-medium text-slate-700">{count}</span>
        </div>
      ))}
    </div>
  );
}

function formatHours(hours: number): string {
  if (hours === 0) return '—';
  if (hours < 1) return `${Math.round(hours * 60)}m`;
  if (hours < 24) return `${hours.toFixed(1)}h`;
  const days = Math.floor(hours / 24);
  const rem = Math.round(hours % 24);
  return rem > 0 ? `${days}d ${rem}h` : `${days}d`;
}
