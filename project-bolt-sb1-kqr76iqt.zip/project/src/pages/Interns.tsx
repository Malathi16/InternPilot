import { useState, useMemo, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import type { Intern, InternInput, InternStatus, Submission, Assignment, AuditLog } from '@/lib/types';
import { INTERN_STATUSES, STATUS_STYLES, DEPARTMENTS, SUBMISSION_STATUS_STYLES } from '@/lib/constants';
import { Badge, Button, Card, EmptyState, Input, Modal, Select, Spinner, Textarea } from '@/components/ui';
import { Search, Plus, Pencil, Trash2, Users, X, Mail, Phone, Briefcase, Calendar, Award, ChevronLeft, History } from 'lucide-react';

interface InternsProps {
  interns: Intern[];
  submissions: Submission[];
  assignments: Assignment[];
  loading: boolean;
  role: string;
  reload: () => void;
  onRoleIntern: (intern: Intern) => void;
}

const emptyInput: InternInput = {
  full_name: '', email: '', phone: '', intern_id: '', department: 'Engineering',
  role: '', project: '', mentor: '', supervisor: '', start_date: new Date().toISOString().slice(0, 10),
  end_date: '', status: 'Active', skills: [], learning_goals: '', notes: '',
};

export function Interns({ interns, submissions, assignments, loading, role, reload, onRoleIntern }: InternsProps) {
  const [search, setSearch] = useState('');
  const [deptFilter, setDeptFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [page, setPage] = useState(0);
  const [selected, setSelected] = useState<Intern | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [editTarget, setEditTarget] = useState<Intern | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Intern | null>(null);
  const [form, setForm] = useState<InternInput>(emptyInput);
  const [skillsInput, setSkillsInput] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const pageSize = 8;

  const canManage = role === 'admin';

  const filtered = useMemo(() => {
    return interns.filter((i) => {
      if (deptFilter !== 'all' && i.department !== deptFilter) return false;
      if (statusFilter !== 'all' && i.status !== statusFilter) return false;
      if (search) {
        const q = search.toLowerCase();
        return (
          i.full_name.toLowerCase().includes(q) ||
          i.intern_id.toLowerCase().includes(q) ||
          (i.mentor ?? '').toLowerCase().includes(q) ||
          (i.project ?? '').toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [interns, search, deptFilter, statusFilter]);

  const paginated = filtered.slice(page * pageSize, (page + 1) * pageSize);
  const totalPages = Math.ceil(filtered.length / pageSize);

  const openAdd = () => {
    setEditTarget(null);
    setForm(emptyInput);
    setSkillsInput('');
    setError(null);
    setShowForm(true);
  };

  const openEdit = (intern: Intern) => {
    setEditTarget(intern);
    setForm({
      full_name: intern.full_name, email: intern.email, phone: intern.phone ?? '', intern_id: intern.intern_id,
      department: intern.department, role: intern.role, project: intern.project ?? '', mentor: intern.mentor ?? '',
      supervisor: intern.supervisor ?? '', start_date: intern.start_date, end_date: intern.end_date ?? '',
      status: intern.status, skills: intern.skills, learning_goals: intern.learning_goals ?? '', notes: intern.notes ?? '',
      photo_url: intern.photo_url,
    });
    setSkillsInput(intern.skills.join(', '));
    setError(null);
    setShowForm(true);
  };

  const save = async () => {
    setSaving(true);
    setError(null);
    const skills = skillsInput.split(',').map((s) => s.trim()).filter(Boolean);
    const payload = { ...form, skills, end_date: form.end_date || null, phone: form.phone || null, project: form.project || null, mentor: form.mentor || null, supervisor: form.supervisor || null, learning_goals: form.learning_goals || null, notes: form.notes || null };

    if (editTarget) {
      const changes: string[] = [];
      if (editTarget.mentor !== form.mentor) changes.push(`Mentor: "${editTarget.mentor}" → "${form.mentor}"`);
      if (editTarget.project !== form.project) changes.push(`Project: "${editTarget.project}" → "${form.project}"`);
      if (editTarget.status !== form.status) changes.push(`Status: ${editTarget.status} → ${form.status}`);

      const { error: e } = await supabase.from('interns').update(payload).eq('id', editTarget.id);
      if (e) { setError(e.message); setSaving(false); return; }

      if (changes.length > 0) {
        await supabase.from('audit_log').insert({
          intern_id: editTarget.id,
          action: 'Updated',
          details: changes.join('; '),
          actor: role.charAt(0).toUpperCase() + role.slice(1),
        });
      }
    } else {
      const { error: e } = await supabase.from('interns').insert(payload);
      if (e) { setError(e.message); setSaving(false); return; }
      await supabase.from('audit_log').insert({
        intern_id: null, action: 'Created', details: `Intern ${form.full_name} (${form.intern_id}) created.`,
        actor: role.charAt(0).toUpperCase() + role.slice(1),
      });
    }
    setSaving(false);
    setShowForm(false);
    reload();
  };

  const doDelete = async () => {
    if (!deleteTarget) return;
    setSaving(true);
    // Soft delete: mark inactive + status Terminated
    const { error: e } = await supabase.from('interns')
      .update({ is_active: false, status: 'Terminated' })
      .eq('id', deleteTarget.id);
    if (e) { setError(e.message); setSaving(false); return; }
    await supabase.from('audit_log').insert({
      intern_id: deleteTarget.id, action: 'Deactivated',
      details: `Intern ${deleteTarget.full_name} deactivated. Sessions revoked.`,
      actor: role.charAt(0).toUpperCase() + role.slice(1),
    });
    setSaving(false);
    setDeleteTarget(null);
    reload();
  };

  if (selected) {
    return <InternDetail intern={selected} submissions={submissions} assignments={assignments} onBack={() => setSelected(null)} onEdit={() => { openEdit(selected); setSelected(null); }} canManage={canManage} />;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">Interns</h1>
          <p className="mt-1 text-sm text-slate-500">{filtered.length} intern{filtered.length !== 1 ? 's' : ''} · {interns.filter((i) => i.status === 'Active').length} active</p>
        </div>
        {canManage && <Button onClick={openAdd}><Plus className="h-4 w-4" /> Add Intern</Button>}
      </div>

      <Card className="p-4">
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
          <div className="relative sm:col-span-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input
              value={search}
              onChange={(e) => { setSearch(e.target.value); setPage(0); }}
              placeholder="Search name, ID, mentor, project..."
              className="w-full rounded-lg border-0 bg-white pl-10 pr-3 py-2.5 text-sm ring-1 ring-inset ring-slate-300 focus:ring-2 focus:ring-slate-600"
            />
          </div>
          <Select value={deptFilter} onChange={(v) => { setDeptFilter(v); setPage(0); }} options={[{ value: 'all', label: 'All Departments' }, ...DEPARTMENTS.map((d) => ({ value: d, label: d }))]} />
          <Select value={statusFilter} onChange={(v) => { setStatusFilter(v); setPage(0); }} options={[{ value: 'all', label: 'All Statuses' }, ...INTERN_STATUSES.map((s) => ({ value: s, label: s }))]} />
        </div>
      </Card>

      {loading ? <Spinner className="py-20" /> : filtered.length === 0 ? (
        <Card><EmptyState icon={<Users className="h-6 w-6" />} title="No interns found" subtitle="Try adjusting your filters or add a new intern." /></Card>
      ) : (
        <>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {paginated.map((intern) => {
              const internSubs = submissions.filter((s) => s.intern_id === intern.id);
              const approved = internSubs.filter((s) => s.status === 'Approved').length;
              const pct = internSubs.length > 0 ? Math.round((approved / internSubs.length) * 100) : 0;
              return (
                <Card key={intern.id} className="group cursor-pointer p-5 transition hover:shadow-md hover:ring-slate-300" >
                  <div onClick={() => setSelected(intern)}>
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        {intern.photo_url ? (
                          <img src={intern.photo_url} alt="" className="h-12 w-12 rounded-full object-cover ring-2 ring-slate-100" />
                        ) : (
                          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-slate-900 text-sm font-bold text-white">
                            {intern.full_name.split(' ').map((n) => n[0]).join('').slice(0, 2)}
                          </div>
                        )}
                        <div className="min-w-0">
                          <p className="truncate text-sm font-semibold text-slate-900">{intern.full_name}</p>
                          <p className="truncate text-xs text-slate-500">{intern.intern_id}</p>
                        </div>
                      </div>
                      <Badge className={STATUS_STYLES[intern.status]}>{intern.status}</Badge>
                    </div>
                    <div className="mt-4 space-y-1.5 text-xs text-slate-500">
                      <p className="truncate"><Briefcase className="mr-1.5 inline h-3.5 w-3.5" />{intern.role} · {intern.department}</p>
                      <p className="truncate"><Users className="mr-1.5 inline h-3.5 w-3.5" />Mentor: {intern.mentor ?? 'Unassigned'}</p>
                    </div>
                    <div className="mt-3">
                      <div className="mb-1 flex items-center justify-between text-xs">
                        <span className="text-slate-400">Task completion</span>
                        <span className="font-medium text-slate-600">{pct}%</span>
                      </div>
                      <div className="h-1.5 overflow-hidden rounded-full bg-slate-100">
                        <div className="h-full rounded-full bg-emerald-500 transition-all" style={{ width: `${pct}%` }} />
                      </div>
                    </div>
                  </div>
                  {canManage && (
                    <div className="mt-3 flex gap-2 border-t border-slate-100 pt-3 opacity-0 transition group-hover:opacity-100">
                      <Button size="sm" variant="secondary" onClick={() => openEdit(intern)}><Pencil className="h-3.5 w-3.5" /> Edit</Button>
                      <Button size="sm" variant="ghost" onClick={() => setDeleteTarget(intern)} className="text-rose-600 hover:bg-rose-50"><Trash2 className="h-3.5 w-3.5" /></Button>
                      <Button size="sm" variant="ghost" onClick={() => onRoleIntern(intern)} className="ml-auto">View as intern</Button>
                    </div>
                  )}
                </Card>
              );
            })}
          </div>

          {totalPages > 1 && (
            <div className="flex items-center justify-center gap-2">
              <Button size="sm" variant="secondary" disabled={page === 0} onClick={() => setPage((p) => p - 1)}>Previous</Button>
              <span className="text-sm text-slate-500">Page {page + 1} of {totalPages}</span>
              <Button size="sm" variant="secondary" disabled={page >= totalPages - 1} onClick={() => setPage((p) => p + 1)}>Next</Button>
            </div>
          )}
        </>
      )}

      <Modal open={showForm} onClose={() => setShowForm(false)} title={editTarget ? 'Edit Intern' : 'Add New Intern'} size="lg">
        <div className="space-y-4">
          {error && <div className="rounded-lg bg-rose-50 px-4 py-3 text-sm text-rose-700 ring-1 ring-rose-200">{error}</div>}
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <Input label="Full Name" value={form.full_name} onChange={(v) => setForm({ ...form, full_name: v })} required />
            <Input label="Intern ID" value={form.intern_id} onChange={(v) => setForm({ ...form, intern_id: v })} placeholder="IP-2026-001" required />
            <Input label="Email" type="email" value={form.email} onChange={(v) => setForm({ ...form, email: v })} required />
            <Input label="Phone" value={form.phone ?? ''} onChange={(v) => setForm({ ...form, phone: v })} placeholder="+91 ..." />
            <Select label="Department" value={form.department} onChange={(v) => setForm({ ...form, department: v })} options={DEPARTMENTS.map((d) => ({ value: d, label: d }))} required />
            <Input label="Internship Role" value={form.role} onChange={(v) => setForm({ ...form, role: v })} required />
            <Input label="Assigned Project" value={form.project ?? ''} onChange={(v) => setForm({ ...form, project: v })} />
            <Input label="Mentor" value={form.mentor ?? ''} onChange={(v) => setForm({ ...form, mentor: v })} />
            <Input label="Supervisor" value={form.supervisor ?? ''} onChange={(v) => setForm({ ...form, supervisor: v })} />
            <Select label="Status" value={form.status} onChange={(v) => setForm({ ...form, status: v as InternStatus })} options={INTERN_STATUSES.map((s) => ({ value: s, label: s }))} required />
            <Input label="Start Date" type="date" value={form.start_date} onChange={(v) => setForm({ ...form, start_date: v })} required />
            <Input label="End Date" type="date" value={form.end_date ?? ''} onChange={(v) => setForm({ ...form, end_date: v })} />
          </div>
          <Input label="Skills (comma-separated)" value={skillsInput} onChange={setSkillsInput} placeholder="React, TypeScript, ..." />
          <Textarea label="Learning Goals" value={form.learning_goals ?? ''} onChange={(v) => setForm({ ...form, learning_goals: v })} rows={2} />
          <Textarea label="Notes" value={form.notes ?? ''} onChange={(v) => setForm({ ...form, notes: v })} rows={2} />
          <div className="flex justify-end gap-2 border-t border-slate-100 pt-4">
            <Button variant="secondary" onClick={() => setShowForm(false)}>Cancel</Button>
            <Button onClick={save} disabled={saving}>{saving ? 'Saving...' : editTarget ? 'Save Changes' : 'Create Intern'}</Button>
          </div>
        </div>
      </Modal>

      <Modal open={!!deleteTarget} onClose={() => setDeleteTarget(null)} title="Deactivate Intern" size="sm">
        <div className="space-y-4">
          <p className="text-sm text-slate-600">
            You are about to deactivate <strong className="text-slate-900">{deleteTarget?.full_name}</strong> ({deleteTarget?.intern_id}). This is a soft deletion — the account will be marked inactive and all historical records (submissions, reviews, audit logs) will be preserved. The intern will lose access immediately.
          </p>
          {error && <div className="rounded-lg bg-rose-50 px-4 py-3 text-sm text-rose-700">{error}</div>}
          <div className="flex justify-end gap-2">
            <Button variant="secondary" onClick={() => setDeleteTarget(null)}>Cancel</Button>
            <Button variant="danger" onClick={doDelete} disabled={saving}>{saving ? 'Deactivating...' : 'Deactivate'}</Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}

function InternDetail({ intern, submissions, assignments, onBack, onEdit, canManage }: {
  intern: Intern; submissions: Submission[]; assignments: Assignment[]; onBack: () => void; onEdit: () => void; canManage: boolean;
}) {
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [showHistory, setShowHistory] = useState(false);

  useEffect(() => {
    supabase.from('audit_log').select('*').eq('intern_id', intern.id).order('created_at', { ascending: false }).then(({ data }) => setLogs((data as AuditLog[]) ?? []));
  }, [intern.id]);

  const internSubs = submissions.filter((s) => s.intern_id === intern.id);
  const approved = internSubs.filter((s) => s.status === 'Approved').length;
  const pending = internSubs.filter((s) => s.status === 'In Progress' || s.status === 'Submitted' || s.status === 'Under Review' || s.status === 'Changes Requested').length;
  const pct = internSubs.length > 0 ? Math.round((approved / internSubs.length) * 100) : 0;
  const assignmentMap = new Map(assignments.map((a) => [a.id, a]));

  return (
    <div className="space-y-6">
      <button onClick={onBack} className="flex items-center gap-1.5 text-sm font-medium text-slate-500 hover:text-slate-900 transition">
        <ChevronLeft className="h-4 w-4" /> Back to Interns
      </button>

      <Card className="overflow-hidden">
        <div className="h-24 bg-gradient-to-r from-slate-800 to-slate-600" />
        <div className="px-6 pb-6">
          <div className="-mt-10 flex items-end justify-between">
            <div className="flex items-end gap-4">
              {intern.photo_url ? (
                <img src={intern.photo_url} alt="" className="h-20 w-20 rounded-full object-cover ring-4 ring-white" />
              ) : (
                <div className="flex h-20 w-20 items-center justify-center rounded-full bg-slate-900 text-2xl font-bold text-white ring-4 ring-white">
                  {intern.full_name.split(' ').map((n) => n[0]).join('').slice(0, 2)}
                </div>
              )}
              <div className="pb-1">
                <h1 className="text-xl font-bold text-slate-900">{intern.full_name}</h1>
                <p className="text-sm text-slate-500">{intern.role} · {intern.department} · {intern.intern_id}</p>
              </div>
            </div>
            <div className="flex gap-2">
              {canManage && <Button variant="secondary" size="sm" onClick={onEdit}><Pencil className="h-3.5 w-3.5" /> Edit</Button>}
              <Button variant="ghost" size="sm" onClick={() => setShowHistory(true)}><History className="h-3.5 w-3.5" /> Audit History</Button>
            </div>
          </div>

          <div className="mt-4 flex flex-wrap items-center gap-2">
            <Badge className={STATUS_STYLES[intern.status]}>{intern.status}</Badge>
            <Badge className="bg-slate-100 text-slate-600 ring-slate-500/20">Completion: {pct}%</Badge>
          </div>

          <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-3">
            <div className="space-y-3">
              <h3 className="text-sm font-semibold uppercase tracking-wide text-slate-400">Contact</h3>
              <div className="space-y-2 text-sm">
                <p className="flex items-center gap-2 text-slate-600"><Mail className="h-4 w-4 text-slate-400" /> {intern.email}</p>
                {intern.phone && <p className="flex items-center gap-2 text-slate-600"><Phone className="h-4 w-4 text-slate-400" /> {intern.phone}</p>}
              </div>
              <h3 className="pt-2 text-sm font-semibold uppercase tracking-wide text-slate-400">Assignment</h3>
              <div className="space-y-2 text-sm text-slate-600">
                <p className="flex items-center gap-2"><Briefcase className="h-4 w-4 text-slate-400" /> {intern.project ?? 'No project assigned'}</p>
                <p className="flex items-center gap-2"><Users className="h-4 w-4 text-slate-400" /> Mentor: {intern.mentor ?? 'Unassigned'}</p>
                <p className="flex items-center gap-2"><Users className="h-4 w-4 text-slate-400" /> Supervisor: {intern.supervisor ?? 'Unassigned'}</p>
                <p className="flex items-center gap-2"><Calendar className="h-4 w-4 text-slate-400" /> {new Date(intern.start_date).toLocaleDateString()} → {intern.end_date ? new Date(intern.end_date).toLocaleDateString() : 'Open'}</p>
              </div>
              {intern.skills.length > 0 && (
                <>
                  <h3 className="pt-2 text-sm font-semibold uppercase tracking-wide text-slate-400">Skills</h3>
                  <div className="flex flex-wrap gap-1.5">
                    {intern.skills.map((s) => <span key={s} className="rounded-md bg-slate-100 px-2 py-0.5 text-xs font-medium text-slate-600">{s}</span>)}
                  </div>
                </>
              )}
              {intern.learning_goals && (
                <>
                  <h3 className="pt-2 text-sm font-semibold uppercase tracking-wide text-slate-400">Learning Goals</h3>
                  <p className="text-sm text-slate-600">{intern.learning_goals}</p>
                </>
              )}
            </div>

            <div className="lg:col-span-2 space-y-4">
              <div className="grid grid-cols-3 gap-3">
                <Card className="p-4">
                  <p className="text-xs font-medium text-slate-500">Total Submissions</p>
                  <p className="mt-1 text-2xl font-bold text-slate-900">{internSubs.length}</p>
                </Card>
                <Card className="p-4">
                  <p className="text-xs font-medium text-slate-500">Approved</p>
                  <p className="mt-1 text-2xl font-bold text-emerald-600">{approved}</p>
                </Card>
                <Card className="p-4">
                  <p className="text-xs font-medium text-slate-500">Pending</p>
                  <p className="mt-1 text-2xl font-bold text-amber-600">{pending}</p>
                </Card>
              </div>

              <div>
                <h3 className="mb-3 text-sm font-semibold uppercase tracking-wide text-slate-400">Submission History</h3>
                {internSubs.length === 0 ? (
                  <Card className="p-6"><EmptyState icon={<Award className="h-6 w-6" />} title="No submissions yet" /></Card>
                ) : (
                  <div className="space-y-2">
                    {internSubs.sort((a, b) => b.created_at.localeCompare(a.created_at)).map((s) => {
                      const a = assignmentMap.get(s.assignment_id);
                      return (
                        <Card key={s.id} className="flex items-center justify-between p-3">
                          <div className="min-w-0">
                            <p className="truncate text-sm font-medium text-slate-900">{a?.title ?? 'Unknown'}</p>
                            <p className="text-xs text-slate-500">Day {a?.day_number} · v{s.version} · {s.submitted_at ? new Date(s.submitted_at).toLocaleDateString() : 'Draft'}</p>
                          </div>
                          <div className="flex items-center gap-2">
                            {s.score !== null && <span className="text-sm font-bold text-slate-700">{s.score}/5</span>}
                            <Badge className={SUBMISSION_STATUS_STYLES[s.status]}>{s.status}</Badge>
                          </div>
                        </Card>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </Card>

      <Modal open={showHistory} onClose={() => setShowHistory(false)} title="Audit History" size="md">
        {logs.length === 0 ? <EmptyState icon={<History className="h-6 w-6" />} title="No changes recorded" /> : (
          <div className="space-y-3">
            {logs.map((l) => (
              <div key={l.id} className="flex gap-3 rounded-lg border border-slate-100 p-3">
                <div className="mt-1 h-2 w-2 flex-shrink-0 rounded-full bg-slate-400" />
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium text-slate-900">{l.action}</p>
                  {l.details && <p className="text-sm text-slate-500">{l.details}</p>}
                  <p className="mt-0.5 text-xs text-slate-400">{l.actor} · {new Date(l.created_at).toLocaleString()}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </Modal>
    </div>
  );
}
