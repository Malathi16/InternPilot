import { useState, useMemo } from 'react';
import { supabase } from '@/lib/supabase';
import type { Assignment, AssignmentInput, Priority, AssignmentStatus, TargetType, Intern } from '@/lib/types';
import { PRIORITIES, PRIORITY_STYLES, ASSIGNMENT_STATUSES } from '@/lib/constants';
import { Badge, Button, Card, EmptyState, Input, Modal, Select, Spinner, Textarea } from '@/components/ui';
import { Plus, ClipboardList, Calendar, Clock, Paperclip, ChevronLeft, Target, FileText, CheckSquare, BookOpen } from 'lucide-react';

interface AssignmentsProps {
  assignments: Assignment[];
  interns: Intern[];
  loading: boolean;
  role: string;
  reload: () => void;
}

const emptyInput: AssignmentInput = {
  title: '', description: '', day_number: 1, instructions: '', learning_objectives: '', expected_outcome: '',
  assignment_date: new Date().toISOString().slice(0, 10), due_date: '', priority: 'Medium', estimated_time_minutes: 60,
  attachment_urls: [], permitted_formats: ['pdf', 'doc', 'docx', 'png', 'jpg', 'jpeg', 'zip', 'txt', 'py', 'js', 'ts'],
  max_file_size_mb: 10, max_file_count: 5, evaluation_criteria: '', rubric: '', acceptance_criteria: '',
  status: 'published', target_type: 'batch', target_intern_ids: [],
};

export function Assignments({ assignments, interns, loading, role, reload }: AssignmentsProps) {
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState<Assignment | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [editTarget, setEditTarget] = useState<Assignment | null>(null);
  const [form, setForm] = useState<AssignmentInput>(emptyInput);
  const [formatsInput, setFormatsInput] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const canManage = role === 'admin' || role === 'mentor';

  const filtered = useMemo(() => {
    return assignments.filter((a) => {
      if (search) {
        const q = search.toLowerCase();
        return a.title.toLowerCase().includes(q) || String(a.day_number).includes(q);
      }
      return true;
    });
  }, [assignments, search]);

  const openAdd = () => {
    setEditTarget(null);
    setForm(emptyInput);
    setFormatsInput(emptyInput.permitted_formats.join(', '));
    setError(null);
    setShowForm(true);
  };

  const openEdit = (a: Assignment) => {
    setEditTarget(a);
    setForm({
      ...a, due_date: a.due_date ?? '', attachment_urls: a.attachment_urls ?? [],
      permitted_formats: a.permitted_formats ?? [], target_intern_ids: a.target_intern_ids ?? [],
      evaluation_criteria: a.evaluation_criteria ?? '', rubric: a.rubric ?? '', acceptance_criteria: a.acceptance_criteria ?? '',
      description: a.description ?? '', instructions: a.instructions ?? '', learning_objectives: a.learning_objectives ?? '',
      expected_outcome: a.expected_outcome ?? '', estimated_time_minutes: a.estimated_time_minutes ?? 60,
    });
    setFormatsInput((a.permitted_formats ?? []).join(', '));
    setError(null);
    setShowForm(true);
  };

  const save = async () => {
    setSaving(true);
    setError(null);
    const formats = formatsInput.split(',').map((s) => s.trim()).filter(Boolean);
    const payload = {
      ...form, permitted_formats: formats, due_date: form.due_date || null, estimated_time_minutes: form.estimated_time_minutes || null,
      attachment_urls: form.attachment_urls ?? [], target_intern_ids: form.target_intern_ids ?? [],
      description: form.description || null, instructions: form.instructions || null, learning_objectives: form.learning_objectives || null,
      expected_outcome: form.expected_outcome || null, evaluation_criteria: form.evaluation_criteria || null,
      rubric: form.rubric || null, acceptance_criteria: form.acceptance_criteria || null,
    };
    if (editTarget) {
      const { error: e } = await supabase.from('assignments').update(payload).eq('id', editTarget.id);
      if (e) { setError(e.message); setSaving(false); return; }
    } else {
      const { error: e } = await supabase.from('assignments').insert(payload);
      if (e) { setError(e.message); setSaving(false); return; }
    }
    setSaving(false);
    setShowForm(false);
    reload();
  };

  const updateStatus = async (a: Assignment, status: AssignmentStatus) => {
    await supabase.from('assignments').update({ status }).eq('id', a.id);
    reload();
    if (selected?.id === a.id) setSelected({ ...a, status });
  };

  if (selected) {
    return <AssignmentDetail assignment={selected} interns={interns} onBack={() => setSelected(null)} onEdit={() => { openEdit(selected); setSelected(null); }} canManage={canManage} onStatusChange={(s) => updateStatus(selected, s)} />;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">Daily Assignments</h1>
          <p className="mt-1 text-sm text-slate-500">{filtered.length} assignment{filtered.length !== 1 ? 's' : ''}</p>
        </div>
        {canManage && <Button onClick={openAdd}><Plus className="h-4 w-4" /> New Assignment</Button>}
      </div>

      <div className="relative">
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search assignments by title or day number..."
          className="w-full rounded-lg border-0 bg-white px-4 py-2.5 text-sm ring-1 ring-inset ring-slate-300 focus:ring-2 focus:ring-slate-600"
        />
      </div>

      {loading ? <Spinner className="py-20" /> : filtered.length === 0 ? (
        <Card><EmptyState icon={<ClipboardList className="h-6 w-6" />} title="No assignments yet" subtitle={canManage ? 'Create your first daily assignment.' : 'Assignments will appear here soon.'} /></Card>
      ) : (
        <div className="space-y-3">
          {filtered.map((a) => (
            <Card key={a.id} className="group cursor-pointer p-5 transition hover:shadow-md hover:ring-slate-300" >
              <div onClick={() => setSelected(a)} className="flex items-start gap-4">
                <div className="flex h-12 w-12 flex-shrink-0 flex-col items-center justify-center rounded-xl bg-slate-900 text-white">
                  <span className="text-[10px] font-medium uppercase leading-none">Day</span>
                  <span className="text-lg font-bold leading-none">{a.day_number}</span>
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-start justify-between gap-2">
                    <h3 className="text-sm font-semibold text-slate-900">{a.title}</h3>
                    <div className="flex flex-shrink-0 items-center gap-1.5">
                      <Badge className={PRIORITY_STYLES[a.priority]}>{a.priority}</Badge>
                      <Badge className={`capitalize ${a.status === 'published' ? 'bg-emerald-50 text-emerald-700 ring-emerald-600/20' : a.status === 'archived' ? 'bg-slate-100 text-slate-500 ring-slate-500/20' : a.status === 'cancelled' ? 'bg-rose-50 text-rose-700 ring-rose-600/20' : 'bg-amber-50 text-amber-700 ring-amber-600/20'}`}>{a.status}</Badge>
                    </div>
                  </div>
                  {a.description && <p className="mt-1 line-clamp-2 text-sm text-slate-500">{a.description}</p>}
                  <div className="mt-2 flex flex-wrap items-center gap-3 text-xs text-slate-400">
                    <span className="flex items-center gap-1"><Calendar className="h-3.5 w-3.5" />{new Date(a.assignment_date).toLocaleDateString()}</span>
                    {a.due_date && <span className="flex items-center gap-1"><Clock className="h-3.5 w-3.5" />Due {new Date(a.due_date).toLocaleDateString()}</span>}
                    {a.estimated_time_minutes && <span className="flex items-center gap-1"><Clock className="h-3.5 w-3.5" />{a.estimated_time_minutes} min</span>}
                    <span className="flex items-center gap-1"><Target className="h-3.5 w-3.5" />{a.target_type}</span>
                    {a.attachment_urls.length > 0 && <span className="flex items-center gap-1"><Paperclip className="h-3.5 w-3.5" />{a.attachment_urls.length} file{a.attachment_urls.length !== 1 ? 's' : ''}</span>}
                  </div>
                </div>
              </div>
              {canManage && (
                <div className="mt-3 flex gap-2 border-t border-slate-100 pt-3 opacity-0 transition group-hover:opacity-100">
                  <Button size="sm" variant="secondary" onClick={() => openEdit(a)}><Plus className="h-3.5 w-3.5" /> Edit</Button>
                  {a.status === 'published' && <Button size="sm" variant="ghost" onClick={() => updateStatus(a, 'archived')}>Archive</Button>}
                  {a.status === 'archived' && <Button size="sm" variant="ghost" onClick={() => updateStatus(a, 'published')}>Publish</Button>}
                  {a.status !== 'cancelled' && <Button size="sm" variant="ghost" onClick={() => updateStatus(a, 'cancelled')} className="text-rose-600 hover:bg-rose-50">Cancel</Button>}
                </div>
              )}
            </Card>
          ))}
        </div>
      )}

      <Modal open={showForm} onClose={() => setShowForm(false)} title={editTarget ? 'Edit Assignment' : 'Create Daily Assignment'} size="xl">
        <div className="space-y-4">
          {error && <div className="rounded-lg bg-rose-50 px-4 py-3 text-sm text-rose-700 ring-1 ring-rose-200">{error}</div>}
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <Input label="Title" value={form.title} onChange={(v) => setForm({ ...form, title: v })} required className="sm:col-span-2" />
            <Textarea label="Description" value={form.description ?? ''} onChange={(v) => setForm({ ...form, description: v })} rows={2} className="sm:col-span-2" />
            <Input label="Day Number" type="number" value={String(form.day_number)} onChange={(v) => setForm({ ...form, day_number: Number(v) || 1 })} required />
            <Select label="Priority" value={form.priority} onChange={(v) => setForm({ ...form, priority: v as Priority })} options={PRIORITIES.map((p) => ({ value: p, label: p }))} />
            <Input label="Assignment Date" type="date" value={form.assignment_date} onChange={(v) => setForm({ ...form, assignment_date: v })} required />
            <Input label="Due Date" type="date" value={form.due_date ?? ''} onChange={(v) => setForm({ ...form, due_date: v })} />
            <Input label="Estimated Time (minutes)" type="number" value={String(form.estimated_time_minutes ?? 60)} onChange={(v) => setForm({ ...form, estimated_time_minutes: Number(v) || null })} />
            <Select label="Status" value={form.status} onChange={(v) => setForm({ ...form, status: v as AssignmentStatus })} options={ASSIGNMENT_STATUSES.map((s) => ({ value: s, label: s }))} />
            <Select label="Target" value={form.target_type} onChange={(v) => setForm({ ...form, target_type: v as TargetType })} options={[{ value: 'batch', label: 'Entire Batch' }, { value: 'group', label: 'Selected Group' }, { value: 'individual', label: 'Individual' }]} />
            {form.target_type !== 'batch' && (
              <div className="sm:col-span-2">
                <span className="mb-1.5 block text-sm font-medium text-slate-700">Select Interns</span>
                <div className="max-h-32 overflow-y-auto rounded-lg ring-1 ring-inset ring-slate-300 p-2 space-y-1">
                  {interns.filter((i) => i.is_active).map((i) => (
                    <label key={i.id} className="flex items-center gap-2 rounded px-2 py-1 text-sm hover:bg-slate-50 cursor-pointer">
                      <input type="checkbox" checked={form.target_intern_ids.includes(i.id)} onChange={(e) => {
                        setForm({ ...form, target_intern_ids: e.target.checked ? [...form.target_intern_ids, i.id] : form.target_intern_ids.filter((id) => id !== i.id) });
                      }} className="rounded border-slate-300" />
                      <span>{i.full_name} <span className="text-slate-400">({i.intern_id})</span></span>
                    </label>
                  ))}
                </div>
              </div>
            )}
          </div>
          <Textarea label="Instructions" value={form.instructions ?? ''} onChange={(v) => setForm({ ...form, instructions: v })} rows={3} />
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <Textarea label="Learning Objectives" value={form.learning_objectives ?? ''} onChange={(v) => setForm({ ...form, learning_objectives: v })} rows={2} />
            <Textarea label="Expected Outcome" value={form.expected_outcome ?? ''} onChange={(v) => setForm({ ...form, expected_outcome: v })} rows={2} />
          </div>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <Textarea label="Evaluation Criteria" value={form.evaluation_criteria ?? ''} onChange={(v) => setForm({ ...form, evaluation_criteria: v })} rows={2} />
            <Textarea label="Rubric" value={form.rubric ?? ''} onChange={(v) => setForm({ ...form, rubric: v })} rows={2} />
          </div>
          <Textarea label="Acceptance Criteria" value={form.acceptance_criteria ?? ''} onChange={(v) => setForm({ ...form, acceptance_criteria: v })} rows={2} />
          <Input label="Permitted Formats (comma-separated)" value={formatsInput} onChange={setFormatsInput} placeholder="pdf, zip, tsx" />
          <div className="grid grid-cols-2 gap-4">
            <Input label="Max File Size (MB)" type="number" value={String(form.max_file_size_mb)} onChange={(v) => setForm({ ...form, max_file_size_mb: Number(v) || 10 })} />
            <Input label="Max File Count" type="number" value={String(form.max_file_count)} onChange={(v) => setForm({ ...form, max_file_count: Number(v) || 5 })} />
          </div>
          <div className="flex justify-end gap-2 border-t border-slate-100 pt-4">
            <Button variant="secondary" onClick={() => setShowForm(false)}>Cancel</Button>
            <Button onClick={save} disabled={saving}>{saving ? 'Saving...' : editTarget ? 'Save Changes' : 'Create Assignment'}</Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}

function AssignmentDetail({ assignment, interns, onBack, onEdit, canManage, onStatusChange }: {
  assignment: Assignment; interns: Intern[]; onBack: () => void; onEdit: () => void; canManage: boolean; onStatusChange: (s: AssignmentStatus) => void;
}) {
  const targetInterns = assignment.target_type === 'batch'
    ? interns.filter((i) => i.is_active)
    : interns.filter((i) => assignment.target_intern_ids.includes(i.id));

  return (
    <div className="space-y-6">
      <button onClick={onBack} className="flex items-center gap-1.5 text-sm font-medium text-slate-500 hover:text-slate-900 transition">
        <ChevronLeft className="h-4 w-4" /> Back to Assignments
      </button>

      <Card className="p-6">
        <div className="flex items-start gap-4">
          <div className="flex h-14 w-14 flex-shrink-0 flex-col items-center justify-center rounded-xl bg-slate-900 text-white">
            <span className="text-[10px] font-medium uppercase leading-none">Day</span>
            <span className="text-xl font-bold leading-none">{assignment.day_number}</span>
          </div>
          <div className="flex-1">
            <div className="flex items-start justify-between">
              <div>
                <h1 className="text-xl font-bold text-slate-900">{assignment.title}</h1>
                <p className="mt-0.5 text-sm text-slate-500">{assignment.description}</p>
              </div>
              {canManage && <Button variant="secondary" size="sm" onClick={onEdit}><Plus className="h-3.5 w-3.5" /> Edit</Button>}
            </div>
            <div className="mt-3 flex flex-wrap items-center gap-2">
              <Badge className={PRIORITY_STYLES[assignment.priority]}>{assignment.priority} priority</Badge>
              <Badge className={`capitalize ${assignment.status === 'published' ? 'bg-emerald-50 text-emerald-700 ring-emerald-600/20' : 'bg-slate-100 text-slate-500 ring-slate-500/20'}`}>{assignment.status}</Badge>
              <Badge className="bg-slate-100 text-slate-600 ring-slate-500/20 capitalize">{assignment.target_type}</Badge>
            </div>
          </div>
        </div>

        <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
          {[
            { label: 'Assigned', value: new Date(assignment.assignment_date).toLocaleDateString(), icon: Calendar },
            { label: 'Due', value: assignment.due_date ? new Date(assignment.due_date).toLocaleDateString() : '—', icon: Clock },
            { label: 'Est. Time', value: assignment.estimated_time_minutes ? `${assignment.estimated_time_minutes} min` : '—', icon: Clock },
            { label: 'Target Interns', value: String(targetInterns.length), icon: Target },
          ].map((s) => {
            const Icon = s.icon;
            return (
              <div key={s.label} className="rounded-lg bg-slate-50 p-3">
                <p className="flex items-center gap-1 text-xs text-slate-400"><Icon className="h-3.5 w-3.5" /> {s.label}</p>
                <p className="mt-0.5 text-sm font-semibold text-slate-900">{s.value}</p>
              </div>
            );
          })}
        </div>
      </Card>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          {assignment.instructions && (
            <Card className="p-5">
              <h3 className="mb-2 flex items-center gap-2 text-sm font-semibold text-slate-900"><FileText className="h-4 w-4 text-slate-400" /> Instructions</h3>
              <p className="whitespace-pre-wrap text-sm text-slate-600">{assignment.instructions}</p>
            </Card>
          )}
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
            {assignment.learning_objectives && (
              <Card className="p-5">
                <h3 className="mb-2 flex items-center gap-2 text-sm font-semibold text-slate-900"><BookOpen className="h-4 w-4 text-slate-400" /> Learning Objectives</h3>
                <p className="text-sm text-slate-600">{assignment.learning_objectives}</p>
              </Card>
            )}
            {assignment.expected_outcome && (
              <Card className="p-5">
                <h3 className="mb-2 flex items-center gap-2 text-sm font-semibold text-slate-900"><Target className="h-4 w-4 text-slate-400" /> Expected Outcome</h3>
                <p className="text-sm text-slate-600">{assignment.expected_outcome}</p>
              </Card>
            )}
            {assignment.evaluation_criteria && (
              <Card className="p-5">
                <h3 className="mb-2 flex items-center gap-2 text-sm font-semibold text-slate-900"><CheckSquare className="h-4 w-4 text-slate-400" /> Evaluation Criteria</h3>
                <p className="text-sm text-slate-600">{assignment.evaluation_criteria}</p>
              </Card>
            )}
            {assignment.rubric && (
              <Card className="p-5">
                <h3 className="mb-2 flex items-center gap-2 text-sm font-semibold text-slate-900"><CheckSquare className="h-4 w-4 text-slate-400" /> Rubric</h3>
                <p className="text-sm text-slate-600">{assignment.rubric}</p>
              </Card>
            )}
          </div>
          {assignment.acceptance_criteria && (
            <Card className="p-5">
              <h3 className="mb-2 flex items-center gap-2 text-sm font-semibold text-slate-900"><CheckSquare className="h-4 w-4 text-slate-400" /> Acceptance Criteria</h3>
              <p className="text-sm text-slate-600">{assignment.acceptance_criteria}</p>
            </Card>
          )}
        </div>

        <div className="space-y-6">
          <Card className="p-5">
            <h3 className="mb-3 text-sm font-semibold text-slate-900">Submission Settings</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between"><span className="text-slate-500">Max file size</span><span className="font-medium text-slate-900">{assignment.max_file_size_mb} MB</span></div>
              <div className="flex justify-between"><span className="text-slate-500">Max files</span><span className="font-medium text-slate-900">{assignment.max_file_count}</span></div>
              <div>
                <p className="mb-1 text-slate-500">Permitted formats</p>
                <div className="flex flex-wrap gap-1">
                  {assignment.permitted_formats.map((f) => <span key={f} className="rounded bg-slate-100 px-1.5 py-0.5 text-xs font-medium text-slate-600">{f}</span>)}
                </div>
              </div>
            </div>
          </Card>

          <Card className="p-5">
            <h3 className="mb-3 text-sm font-semibold text-slate-900">Target Interns ({targetInterns.length})</h3>
            <div className="space-y-1.5 max-h-48 overflow-y-auto">
              {targetInterns.map((i) => (
                <div key={i.id} className="flex items-center gap-2 text-sm">
                  <div className="flex h-7 w-7 items-center justify-center rounded-full bg-slate-100 text-xs font-semibold text-slate-600">{i.full_name.split(' ').map((n) => n[0]).join('').slice(0, 2)}</div>
                  <span className="truncate text-slate-700">{i.full_name}</span>
                </div>
              ))}
            </div>
          </Card>

          {canManage && (
            <Card className="p-5">
              <h3 className="mb-3 text-sm font-semibold text-slate-900">Manage Status</h3>
              <div className="flex flex-wrap gap-2">
                <Button size="sm" variant={assignment.status === 'published' ? 'primary' : 'secondary'} onClick={() => onStatusChange('published')}>Publish</Button>
                <Button size="sm" variant={assignment.status === 'archived' ? 'primary' : 'secondary'} onClick={() => onStatusChange('archived')}>Archive</Button>
                <Button size="sm" variant={assignment.status === 'cancelled' ? 'danger' : 'secondary'} onClick={() => onStatusChange('cancelled')}>Cancel</Button>
              </div>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
