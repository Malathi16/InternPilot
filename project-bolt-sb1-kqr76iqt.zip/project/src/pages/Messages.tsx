import { useState, useMemo } from 'react';
import { supabase } from '@/lib/supabase';
import type { Message, Intern } from '@/lib/types';
import { PRIORITIES, PRIORITY_STYLES, DEPARTMENTS } from '@/lib/constants';
import { Badge, Button, Card, EmptyState, Input, Modal, Select, Spinner, Textarea } from '@/components/ui';
import { Mail, Send, Inbox, ChevronLeft, ArrowLeft, User, Building2, Star, Trash2, MailOpen } from 'lucide-react';

interface MessagesProps {
  messages: Message[];
  interns: Intern[];
  loading: boolean;
  role: string;
  activeInternId: string | null;
  reload: () => void;
}

export function Messages({ messages, interns, loading, role, activeInternId, reload }: MessagesProps) {
  const [showCompose, setShowCompose] = useState(false);
  const [selected, setSelected] = useState<Message | null>(null);
  const [recipientType, setRecipientType] = useState<'intern' | 'department'>('intern');
  const [toInternId, setToInternId] = useState('');
  const [toDept, setToDept] = useState(DEPARTMENTS[0]);
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');
  const [priority, setPriority] = useState<'Low' | 'Medium' | 'High'>('Medium');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const canSend = role === 'admin' || role === 'mentor';
  const senderName = role === 'admin' ? 'Administrator' : 'Mentor';

  const internMap = useMemo(() => new Map(interns.map((i) => [i.id, i])), [interns]);
  const activeIntern = role === 'intern' ? internMap.get(activeInternId ?? '') : null;
  const activeInternDept = activeIntern?.department;

  const visibleMessages = useMemo(() => {
    if (role === 'intern') {
      return messages.filter((m) => m.to_intern_id === activeInternId || (m.to_department === activeInternDept && !m.to_intern_id));
    }
    return messages;
  }, [messages, role, activeInternId, activeInternDept]);

  const unreadCount = role === 'intern' ? visibleMessages.filter((m) => !m.read_at).length : 0;

  const markRead = async (msg: Message) => {
    if (role !== 'intern' || msg.read_at) return;
    const readAt = new Date().toISOString();
    await supabase.from('messages').update({ read_at: readAt }).eq('id', msg.id);
    reload();
  };

  const openMessage = (msg: Message) => {
    setSelected(msg);
    if (role === 'intern' && !msg.read_at) markRead(msg);
  };

  const send = async () => {
    setSaving(true);
    setError(null);
    if (!subject.trim() || !body.trim()) {
      setError('Subject and message body are required.');
      setSaving(false);
      return;
    }
    const payload = {
      from_role: role === 'admin' ? 'admin' : 'mentor',
      from_name: senderName,
      to_intern_id: recipientType === 'intern' ? (toInternId || null) : null,
      to_department: recipientType === 'department' ? toDept : null,
      subject: subject.trim(),
      body: body.trim(),
      priority,
    };
    if (!payload.to_intern_id && !payload.to_department) {
      setError('Please select a recipient.');
      setSaving(false);
      return;
    }
    const { error: e } = await supabase.from('messages').insert(payload);
    if (e) { setError(e.message); setSaving(false); return; }
    setSaving(false);
    setShowCompose(false);
    setSubject(''); setBody(''); setPriority('Medium'); setToInternId('');
    reload();
  };

  const deleteMessage = async (id: string) => {
    await supabase.from('messages').delete().eq('id', id);
    setSelected(null);
    reload();
  };

  if (selected) {
    return (
      <div className="space-y-6">
        <button onClick={() => setSelected(null)} className="flex items-center gap-1.5 text-sm font-medium text-slate-500 hover:text-slate-900 transition">
          <ChevronLeft className="h-4 w-4" /> Back to Messages
        </button>
        <Card className="p-6">
          <div className="flex items-start justify-between gap-4">
            <div className="min-w-0 flex-1">
              <h1 className="text-xl font-bold text-slate-900">{selected.subject}</h1>
              <div className="mt-2 flex flex-wrap items-center gap-3 text-sm text-slate-500">
                <span className="flex items-center gap-1.5"><User className="h-4 w-4" /> From {selected.from_name}</span>
                <span className="flex items-center gap-1.5">
                  {selected.to_intern_id ? <><User className="h-4 w-4" /> To {internMap.get(selected.to_intern_id)?.full_name ?? 'Intern'}</> : <><Building2 className="h-4 w-4" /> To {selected.to_department} department</>}
                </span>
                <span>{new Date(selected.created_at).toLocaleString()}</span>
              </div>
              <Badge className={`mt-3 ${PRIORITY_STYLES[selected.priority]}`}>{selected.priority} priority</Badge>
            </div>
            {canSend && (
              <Button variant="ghost" size="sm" onClick={() => deleteMessage(selected.id)} className="text-rose-600 hover:bg-rose-50">
                <Trash2 className="h-4 w-4" /> Delete
              </Button>
            )}
          </div>
          <div className="mt-6 whitespace-pre-wrap rounded-lg bg-slate-50 p-4 text-sm text-slate-700">{selected.body}</div>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">Messages</h1>
          <p className="mt-1 text-sm text-slate-500">
            {role === 'intern'
              ? `${unreadCount > 0 ? `${unreadCount} unread message${unreadCount !== 1 ? 's' : ''}` : 'No unread messages'}`
              : 'Send emails to individual interns or broadcast to a department.'}
          </p>
        </div>
        {canSend && <Button onClick={() => setShowCompose(true)}><Send className="h-4 w-4" /> Compose</Button>}
      </div>

      {loading ? <Spinner className="py-20" /> : visibleMessages.length === 0 ? (
        <Card>
          <EmptyState
            icon={<Inbox className="h-6 w-6" />}
            title={role === 'intern' ? 'Your inbox is empty' : 'No messages sent yet'}
            subtitle={role === 'intern' ? 'Messages from your mentor or admin will appear here.' : 'Compose a message to send to your interns.'}
          />
        </Card>
      ) : (
        <div className="space-y-2">
          {visibleMessages.map((m) => {
            const isUnread = role === 'intern' && !m.read_at;
            const recipient = m.to_intern_id ? internMap.get(m.to_intern_id)?.full_name ?? 'Intern' : `${m.to_department} dept`;
            return (
              <Card key={m.id} className={`cursor-pointer p-4 transition hover:shadow-md hover:ring-slate-300 ${isUnread ? 'ring-slate-300 bg-slate-50/50' : ''}`}>
                <div onClick={() => openMessage(m)} className="flex items-center gap-3">
                  <div className="flex h-11 w-11 flex-shrink-0 items-center justify-center rounded-lg bg-slate-100">
                    {isUnread ? <Mail className="h-5 w-5 text-slate-700" /> : <MailOpen className="h-5 w-5 text-slate-400" />}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      {isUnread && <span className="h-2 w-2 flex-shrink-0 rounded-full bg-sky-500" />}
                      <p className={`truncate text-sm ${isUnread ? 'font-bold text-slate-900' : 'font-medium text-slate-800'}`}>{m.subject}</p>
                    </div>
                    <p className="truncate text-xs text-slate-500">
                      {role === 'intern' ? `From ${m.from_name}` : `To ${recipient}`} · {new Date(m.created_at).toLocaleDateString()}
                    </p>
                  </div>
                  <div className="flex flex-shrink-0 items-center gap-2">
                    <Badge className={PRIORITY_STYLES[m.priority]}>{m.priority}</Badge>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      <Modal open={showCompose} onClose={() => setShowCompose(false)} title="Compose Message" size="lg">
        <div className="space-y-4">
          {error && <div className="rounded-lg bg-rose-50 px-4 py-3 text-sm text-rose-700 ring-1 ring-rose-200">{error}</div>}
          <div>
            <span className="mb-1.5 block text-sm font-medium text-slate-700">Recipient</span>
            <div className="grid grid-cols-2 gap-2">
              <button onClick={() => setRecipientType('intern')} className={`flex items-center gap-2 rounded-lg px-3 py-2.5 text-sm font-medium transition ${recipientType === 'intern' ? 'bg-slate-900 text-white' : 'bg-slate-50 text-slate-600 hover:bg-slate-100'}`}>
                <User className="h-4 w-4" /> Individual Intern
              </button>
              <button onClick={() => setRecipientType('department')} className={`flex items-center gap-2 rounded-lg px-3 py-2.5 text-sm font-medium transition ${recipientType === 'department' ? 'bg-slate-900 text-white' : 'bg-slate-50 text-slate-600 hover:bg-slate-100'}`}>
                <Building2 className="h-4 w-4" /> Entire Department
              </button>
            </div>
          </div>
          {recipientType === 'intern' ? (
            <Select label="Select Intern" value={toInternId} onChange={setToInternId} options={[{ value: '', label: 'Choose an intern...' }, ...interns.filter((i) => i.is_active).map((i) => ({ value: i.id, label: `${i.full_name} (${i.intern_id})` }))]} required />
          ) : (
            <Select label="Select Department" value={toDept} onChange={setToDept} options={DEPARTMENTS.map((d) => ({ value: d, label: d }))} required />
          )}
          <Input label="Subject" value={subject} onChange={setSubject} placeholder="Message subject..." required />
          <Textarea label="Message" value={body} onChange={setBody} rows={6} placeholder="Write your message to the intern(s)..." />
          <Select label="Priority" value={priority} onChange={(v) => setPriority(v as 'Low' | 'Medium' | 'High')} options={PRIORITIES.map((p) => ({ value: p, label: p }))} />
          <div className="flex justify-end gap-2 border-t border-slate-100 pt-4">
            <Button variant="secondary" onClick={() => setShowCompose(false)}>Cancel</Button>
            <Button onClick={send} disabled={saving}><Send className="h-4 w-4" /> {saving ? 'Sending...' : 'Send Message'}</Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
