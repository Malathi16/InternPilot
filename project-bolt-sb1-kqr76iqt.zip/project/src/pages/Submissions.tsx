import { useState, useMemo } from 'react';
import { supabase } from '@/lib/supabase';
import type { Submission, SubmissionStatus, Assignment, Intern } from '@/lib/types';
import { SUBMISSION_STATUSES, SUBMISSION_STATUS_STYLES } from '@/lib/constants';
import { Badge, Button, Card, EmptyState, Modal, Select, Spinner, Textarea, Input } from '@/components/ui';
import { FileUp, Upload, ChevronLeft, History, GitBranch, Link2, FileCheck, CheckCircle2, Clock, Star } from 'lucide-react';

interface SubmissionsProps {
  submissions: Submission[];
  assignments: Assignment[];
  interns: Intern[];
  loading: boolean;
  role: string;
  activeInternId: string | null;
  reload: () => void;
  goToAssignment: (a: Assignment) => void;
}

export function Submissions({ submissions, assignments, interns, loading, role, activeInternId, reload, goToAssignment }: SubmissionsProps) {
  const [filterIntern, setFilterIntern] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');
  const [selected, setSelected] = useState<Submission | null>(null);

  const assignmentMap = useMemo(() => new Map(assignments.map((a) => [a.id, a])), [assignments]);
  const internMap = useMemo(() => new Map(interns.map((i) => [i.id, i])), [interns]);

  const visibleSubs = useMemo(() => {
    let subs = role === 'intern' ? submissions.filter((s) => s.intern_id === activeInternId) : submissions;
    if (filterIntern !== 'all') subs = subs.filter((s) => s.intern_id === filterIntern);
    if (filterStatus !== 'all') subs = subs.filter((s) => s.status === filterStatus);
    return [...subs].sort((a, b) => (b.submitted_at ?? b.created_at).localeCompare(a.submitted_at ?? a.created_at));
  }, [submissions, role, activeInternId, filterIntern, filterStatus]);

  if (selected) {
    return <SubmissionDetail
      submission={selected}
      assignment={assignmentMap.get(selected.assignment_id)}
      intern={internMap.get(selected.intern_id)}
      allVersions={submissions.filter((s) => s.assignment_id === selected.assignment_id && s.intern_id === selected.intern_id).sort((a, b) => a.version - b.version)}
      role={role}
      onBack={() => setSelected(null)}
      reload={reload}
      goToAssignment={goToAssignment}
    />;
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">Submissions</h1>
        <p className="mt-1 text-sm text-slate-500">{visibleSubs.length} submission{visibleSubs.length !== 1 ? 's' : ''}{role === 'intern' ? ' from you' : ''}</p>
      </div>

      {role !== 'intern' && (
        <Card className="p-4">
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <Select label="Intern" value={filterIntern} onChange={setFilterIntern} options={[{ value: 'all', label: 'All Interns' }, ...interns.filter((i) => i.is_active).map((i) => ({ value: i.id, label: i.full_name }))]} />
            <Select label="Status" value={filterStatus} onChange={setFilterStatus} options={[{ value: 'all', label: 'All Statuses' }, ...SUBMISSION_STATUSES.map((s) => ({ value: s, label: s }))]} />
          </div>
        </Card>
      )}

      {loading ? <Spinner className="py-20" /> : visibleSubs.length === 0 ? (
        <Card><EmptyState icon={<FileUp className="h-6 w-6" />} title="No submissions found" subtitle="Submissions will appear here once work is submitted." /></Card>
      ) : (
        <div className="space-y-3">
          {visibleSubs.map((s) => {
            const a = assignmentMap.get(s.assignment_id);
            const i = internMap.get(s.intern_id);
            return (
              <Card key={s.id} className="cursor-pointer p-4 transition hover:shadow-md hover:ring-slate-300" >
                <div onClick={() => setSelected(s)} className="flex items-center gap-4">
                  <div className="flex h-11 w-11 flex-shrink-0 items-center justify-center rounded-lg bg-slate-100">
                    {s.status === 'Approved' ? <CheckCircle2 className="h-5 w-5 text-emerald-500" /> : s.status === 'In Progress' ? <Clock className="h-5 w-5 text-amber-500" /> : <FileCheck className="h-5 w-5 text-slate-400" />}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold text-slate-900">{a?.title ?? 'Unknown assignment'}</p>
                    <p className="truncate text-xs text-slate-500">
                      {i?.full_name ?? 'Unknown'} · Day {a?.day_number} · v{s.version}
                      {s.submitted_at && ` · ${new Date(s.submitted_at).toLocaleDateString()}`}
                    </p>
                  </div>
                  <div className="flex flex-shrink-0 items-center gap-2">
                    {s.score !== null && <span className="flex items-center gap-0.5 text-sm font-bold text-slate-700"><Star className="h-3.5 w-3.5 text-amber-400" />{s.score}</span>}
                    <Badge className={SUBMISSION_STATUS_STYLES[s.status]}>{s.status}</Badge>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}

function SubmissionDetail({ submission, assignment, intern, allVersions, role, onBack, reload, goToAssignment }: {
  submission: Submission; assignment?: Assignment; intern?: Intern; allVersions: Submission[]; role: string; onBack: () => void; reload: () => void; goToAssignment: (a: Assignment) => void;
}) {
  const [showSubmit, setShowSubmit] = useState(false);
  const [showReview, setShowReview] = useState(false);
  const isIntern = role === 'intern';
  const isMentorOrAdmin = role === 'mentor' || role === 'admin';

  return (
    <div className="space-y-6">
      <button onClick={onBack} className="flex items-center gap-1.5 text-sm font-medium text-slate-500 hover:text-slate-900 transition">
        <ChevronLeft className="h-4 w-4" /> Back to Submissions
      </button>

      <Card className="p-6">
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-xl font-bold text-slate-900">{assignment?.title ?? 'Submission'}</h1>
            <p className="mt-1 text-sm text-slate-500">
              {intern?.full_name} · Day {assignment?.day_number} · Version {submission.version}
            </p>
          </div>
          <Badge className={SUBMISSION_STATUS_STYLES[submission.status]}>{submission.status}</Badge>
        </div>

        {submission.score !== null && (
          <div className="mt-4 flex items-center gap-3 rounded-lg bg-amber-50 px-4 py-3 ring-1 ring-amber-200">
            <Star className="h-5 w-5 text-amber-500" />
            <div>
              <p className="text-sm font-semibold text-amber-900">Score: {submission.score}/5</p>
              {submission.mentor_feedback && <p className="text-sm text-amber-700">{submission.mentor_feedback}</p>}
            </div>
          </div>
        )}

        {submission.resubmission_reason && (
          <div className="mt-4 rounded-lg bg-orange-50 px-4 py-3 ring-1 ring-orange-200">
            <p className="text-xs font-medium uppercase tracking-wide text-orange-600">Resubmission Reason</p>
            <p className="mt-1 text-sm text-orange-800">{submission.resubmission_reason}</p>
          </div>
        )}

        <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-3">
          <div className="space-y-4 lg:col-span-2">
            {submission.notes && (
              <div>
                <h3 className="mb-1.5 text-sm font-semibold text-slate-900">Submission Notes</h3>
                <p className="whitespace-pre-wrap rounded-lg bg-slate-50 p-3 text-sm text-slate-600">{submission.notes}</p>
              </div>
            )}
            {(submission.repo_url || submission.deployed_url) && (
              <div>
                <h3 className="mb-1.5 text-sm font-semibold text-slate-900">Links</h3>
                <div className="space-y-1.5">
                  {submission.repo_url && <a href={submission.repo_url} target="_blank" rel="noreferrer" className="flex items-center gap-2 text-sm text-sky-600 hover:underline"><GitBranch className="h-4 w-4" /> {submission.repo_url}</a>}
                  {submission.deployed_url && <a href={submission.deployed_url} target="_blank" rel="noreferrer" className="flex items-center gap-2 text-sm text-sky-600 hover:underline"><Link2 className="h-4 w-4" /> {submission.deployed_url}</a>}
                </div>
              </div>
            )}
            <div>
              <h3 className="mb-1.5 text-sm font-semibold text-slate-900">Attached Files</h3>
              {submission.file_names.length === 0 ? (
                <p className="text-sm text-slate-400">No files attached.</p>
              ) : (
                <div className="space-y-1.5">
                  {submission.file_names.map((f, idx) => (
                    <div key={idx} className="flex items-center gap-2 rounded-lg border border-slate-100 px-3 py-2 text-sm">
                      <FileCheck className="h-4 w-4 text-slate-400" />
                      <span className="text-slate-700">{f}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          <div className="space-y-3">
            <div className="rounded-lg bg-slate-50 p-3 text-sm">
              <p className="text-xs text-slate-400">Submitted</p>
              <p className="font-medium text-slate-900">{submission.submitted_at ? new Date(submission.submitted_at).toLocaleString() : 'Not submitted (draft)'}</p>
            </div>
            {assignment && (
              <Button variant="secondary" className="w-full" onClick={() => goToAssignment(assignment)}>View Assignment</Button>
            )}
            {isIntern && (submission.status === 'Changes Requested' || submission.status === 'In Progress' || submission.status === 'Not Started') && (
              <Button className="w-full" onClick={() => setShowSubmit(true)}><Upload className="h-4 w-4" /> {submission.version > 0 && submission.status !== 'Not Started' ? 'Resubmit' : 'Submit Work'}</Button>
            )}
            {isMentorOrAdmin && (submission.status === 'Submitted' || submission.status === 'Resubmitted' || submission.status === 'Under Review') && (
              <Button className="w-full" onClick={() => setShowReview(true)}><CheckCircle2 className="h-4 w-4" /> Review Submission</Button>
            )}
          </div>
        </div>
      </Card>

      <Card className="p-5">
        <h3 className="mb-4 flex items-center gap-2 text-sm font-semibold text-slate-900"><History className="h-4 w-4 text-slate-400" /> Version History</h3>
        {allVersions.length <= 1 ? (
          <p className="text-sm text-slate-400">This is the only version.</p>
        ) : (
          <div className="space-y-2">
            {allVersions.map((v) => (
              <div key={v.id} className={`flex items-center gap-3 rounded-lg border p-3 ${v.id === submission.id ? 'border-slate-300 bg-slate-50' : 'border-slate-100'}`}>
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-white ring-1 ring-slate-200 text-xs font-bold text-slate-600">v{v.version}</div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium text-slate-900">Version {v.version}</p>
                  <p className="text-xs text-slate-500">{v.submitted_at ? new Date(v.submitted_at).toLocaleString() : 'Draft'}</p>
                </div>
                <Badge className={SUBMISSION_STATUS_STYLES[v.status]}>{v.status}</Badge>
                {v.id !== submission.id && <Button size="sm" variant="ghost" onClick={() => onBack()}>View</Button>}
              </div>
            ))}
          </div>
        )}
      </Card>

      {showSubmit && assignment && (
        <SubmitModal
          open={showSubmit}
          onClose={() => setShowSubmit(false)}
          assignment={assignment}
          existingVersion={submission.version}
          internId={submission.intern_id}
          isResubmission={submission.status === 'Changes Requested'}
          onDone={() => { setShowSubmit(false); reload(); onBack(); }}
        />
      )}

      {showReview && (
        <ReviewModal
          open={showReview}
          onClose={() => setShowReview(false)}
          submission={submission}
          onDone={() => { setShowReview(false); reload(); onBack(); }}
        />
      )}
    </div>
  );
}

function SubmitModal({ open, onClose, assignment, existingVersion, internId, isResubmission, onDone }: {
  open: boolean; onClose: () => void; assignment: Assignment; existingVersion: number; internId: string; isResubmission: boolean; onDone: () => void;
}) {
  const [notes, setNotes] = useState('');
  const [repoUrl, setRepoUrl] = useState('');
  const [deployedUrl, setDeployedUrl] = useState('');
  const [resubmissionReason, setResubmissionReason] = useState('');
  const [files, setFiles] = useState<File[]>([]);
  const [errors, setErrors] = useState<string[]>([]);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const validateFiles = (incoming: File[]): string[] => {
    const errs: string[] = [];
    const allowed = assignment.permitted_formats;
    for (const f of incoming) {
      const ext = f.name.split('.').pop()?.toLowerCase() ?? '';
      if (!allowed.includes(ext)) errs.push(`${f.name}: .${ext} not permitted (allowed: ${allowed.join(', ')})`);
      if (f.size > assignment.max_file_size_mb * 1024 * 1024) errs.push(`${f.name}: exceeds ${assignment.max_file_size_mb} MB limit`);
    }
    if (incoming.length > assignment.max_file_count) errs.push(`Too many files: max ${assignment.max_file_count} allowed`);
    return errs;
  };

  const onFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const incoming = Array.from(e.target.files ?? []);
    setErrors(validateFiles(incoming));
    setFiles(incoming);
  };

  const submit = async () => {
    setSaving(true);
    setError(null);

    // Generate unique storage keys (don't trust user filenames)
    const ts = Date.now();
    const fileNames = files.map((f) => f.name);
    const storagePaths = files.map((f, idx) => `submissions/${internId}/${assignment.id}/v${existingVersion + 1}/${ts}-${idx}-${f.name.replace(/[^a-zA-Z0-9._-]/g, '_')}`);

    // Upload to Supabase Storage (private bucket)
    for (let i = 0; i < files.length; i++) {
      const { error: upErr } = await supabase.storage
        .from('submissions')
        .upload(storagePaths[i], files[i], { contentType: files[i].type, upsert: false });
      if (upErr && upErr.message !== 'The resource already exists') {
        setError(`Upload failed for ${files[i].name}: ${upErr.message}`);
        setSaving(false);
        return;
      }
    }

    const status: SubmissionStatus = isResubmission ? 'Resubmitted' : 'Submitted';
    const newVersion = existingVersion + 1;

    const { error: insErr } = await supabase.from('submissions').insert({
      intern_id: internId,
      assignment_id: assignment.id,
      version: newVersion,
      file_names: fileNames,
      storage_paths: storagePaths,
      repo_url: repoUrl || null,
      deployed_url: deployedUrl || null,
      notes: notes || null,
      status,
      resubmission_reason: isResubmission ? (resubmissionReason || null) : null,
      submitted_at: new Date().toISOString(),
    });

    if (insErr) { setError(insErr.message); setSaving(false); return; }

    setSaving(false);
    onDone();
  };

  return (
    <Modal open={open} onClose={onClose} title={isResubmission ? `Resubmit — Version ${existingVersion + 1}` : 'Submit Assignment Work'} size="lg">
      <div className="space-y-4">
        {error && <div className="rounded-lg bg-rose-50 px-4 py-3 text-sm text-rose-700 ring-1 ring-rose-200">{error}</div>}
        <div className="rounded-lg bg-slate-50 p-3 text-sm text-slate-600">
          <p><strong>{assignment.title}</strong> · Day {assignment.day_number}</p>
          <p className="mt-1 text-xs">Allowed: {assignment.permitted_formats.join(', ')} · Max {assignment.max_file_size_mb} MB/file · Max {assignment.max_file_count} files</p>
        </div>
        <div>
          <span className="mb-1.5 block text-sm font-medium text-slate-700">Upload Files</span>
          <label className="flex cursor-pointer flex-col items-center justify-center rounded-lg border-2 border-dashed border-slate-300 py-8 transition hover:border-slate-400 hover:bg-slate-50">
            <Upload className="h-7 w-7 text-slate-400" />
            <span className="mt-2 text-sm text-slate-500">Click to select files</span>
            <input type="file" multiple className="hidden" onChange={onFileChange} />
          </label>
          {files.length > 0 && (
            <div className="mt-2 space-y-1">
              {files.map((f, i) => <p key={i} className="text-xs text-slate-600">{f.name} ({(f.size / 1024).toFixed(0)} KB)</p>)}
            </div>
          )}
          {errors.length > 0 && (
            <div className="mt-2 space-y-0.5">
              {errors.map((e, i) => <p key={i} className="text-xs text-rose-600">{e}</p>)}
            </div>
          )}
        </div>
        <Input label="GitHub Repository URL" value={repoUrl} onChange={setRepoUrl} placeholder="https://github.com/..." />
        <Input label="Deployed Project URL" value={deployedUrl} onChange={setDeployedUrl} placeholder="https://..." />
        <Textarea label="Solution Description & Challenges" value={notes} onChange={setNotes} rows={3} placeholder="Explain your approach and any challenges you faced..." />
        {isResubmission && (
          <Textarea label="Resubmission Reason" value={resubmissionReason} onChange={setResubmissionReason} rows={2} placeholder="What did you change since the last version?" />
        )}
        <div className="flex justify-end gap-2 border-t border-slate-100 pt-4">
          <Button variant="secondary" onClick={onClose}>Cancel</Button>
          <Button onClick={submit} disabled={saving || errors.length > 0}>{saving ? 'Submitting...' : 'Submit Work'}</Button>
        </div>
      </div>
    </Modal>
  );
}

function ReviewModal({ open, onClose, submission, onDone }: { open: boolean; onClose: () => void; submission: Submission; onDone: () => void }) {
  const [status, setStatus] = useState<SubmissionStatus>('Under Review');
  const [score, setScore] = useState('3');
  const [feedback, setFeedback] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const save = async () => {
    setSaving(true);
    setError(null);
    const { error: e } = await supabase.from('submissions').update({
      status,
      score: Number(score),
      mentor_feedback: feedback || null,
    }).eq('id', submission.id);
    if (e) { setError(e.message); setSaving(false); return; }
    setSaving(false);
    onDone();
  };

  return (
    <Modal open={open} onClose={onClose} title="Review Submission" size="md">
      <div className="space-y-4">
        {error && <div className="rounded-lg bg-rose-50 px-4 py-3 text-sm text-rose-700">{error}</div>}
        <Select label="Evaluation Status" value={status} onChange={(v) => setStatus(v as SubmissionStatus)} options={[
          { value: 'Under Review', label: 'Under Review' },
          { value: 'Changes Requested', label: 'Changes Requested' },
          { value: 'Approved', label: 'Approved' },
        ]} />
        <Select label="Score (out of 5)" value={score} onChange={setScore} options={[1, 2, 3, 4, 5].map((n) => ({ value: String(n), label: `${n} / 5` }))} />
        <Textarea label="Mentor Feedback" value={feedback} onChange={setFeedback} rows={4} placeholder="Provide constructive feedback for the intern..." />
        <div className="flex justify-end gap-2 border-t border-slate-100 pt-4">
          <Button variant="secondary" onClick={onClose}>Cancel</Button>
          <Button onClick={save} disabled={saving}>{saving ? 'Saving...' : 'Save Review'}</Button>
        </div>
      </div>
    </Modal>
  );
}
