import { useMemo } from 'react';
import type { Assignment, Submission, Intern } from '@/lib/types';
import { PROGRAM_DAYS, SUBMISSION_STATUS_STYLES } from '@/lib/constants';
import { Badge, Card, EmptyState, Spinner } from '@/components/ui';
import { CalendarDays, CheckCircle2, Clock, AlertCircle, Circle, ArrowRight } from 'lucide-react';

interface TimelineProps {
  assignments: Assignment[];
  submissions: Submission[];
  interns: Intern[];
  loading: boolean;
  role: string;
  activeInternId: string | null;
  onSelectAssignment: (a: Assignment) => void;
}

export function Timeline({ assignments, submissions, interns, loading, role, activeInternId, onSelectAssignment }: TimelineProps) {
  const assignmentMap = useMemo(() => new Map(assignments.map((a) => [a.id, a])), [assignments]);
  const mySubs = role === 'intern' ? submissions.filter((s) => s.intern_id === activeInternId) : submissions;
  const subByAssignment = useMemo(() => {
    const m = new Map<string, Submission>();
    mySubs.forEach((s) => {
      const existing = m.get(s.assignment_id);
      if (!existing || s.version > existing.version) m.set(s.assignment_id, s);
    });
    return m;
  }, [mySubs]);

  if (loading) return <Spinner className="py-20" />;

  const days = Array.from({ length: PROGRAM_DAYS }, (_, i) => i + 1);
  const assignmentByDay = useMemo(() => {
    const m = new Map<number, Assignment>();
    assignments.filter((a) => a.status === 'published').forEach((a) => m.set(a.day_number, a));
    return m;
  }, [assignments]);

  const completed = days.filter((d) => { const a = assignmentByDay.get(d); return a && subByAssignment.get(a.id)?.status === 'Approved'; }).length;
  const pending = days.filter((d) => { const a = assignmentByDay.get(d); const s = a && subByAssignment.get(a.id); return a && s && s.status !== 'Approved'; }).length;
  const upcoming = days.filter((d) => { const a = assignmentByDay.get(d); return a && !subByAssignment.get(a.id); }).length;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">Day-by-Day Workflow</h1>
        <p className="mt-1 text-sm text-slate-500">Structured {PROGRAM_DAYS}-day internship program timeline.</p>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <Card className="p-4"><div className="flex items-center gap-2"><CheckCircle2 className="h-5 w-5 text-emerald-500" /><div><p className="text-xs text-slate-500">Completed</p><p className="text-xl font-bold text-slate-900">{completed}</p></div></div></Card>
        <Card className="p-4"><div className="flex items-center gap-2"><Clock className="h-5 w-5 text-amber-500" /><div><p className="text-xs text-slate-500">Pending</p><p className="text-xl font-bold text-slate-900">{pending}</p></div></div></Card>
        <Card className="p-4"><div className="flex items-center gap-2"><CalendarDays className="h-5 w-5 text-sky-500" /><div><p className="text-xs text-slate-500">Upcoming</p><p className="text-xl font-bold text-slate-900">{upcoming}</p></div></div></Card>
      </div>

      <div className="relative">
        <div className="absolute left-[27px] top-0 bottom-0 w-px bg-slate-200" />
        <div className="space-y-3">
          {days.map((day) => {
            const assignment = assignmentByDay.get(day);
            const sub = assignment ? subByAssignment.get(assignment.id) : undefined;
            const isComplete = sub?.status === 'Approved';
            const isPending = sub && sub.status !== 'Approved';
            const isOverdue = sub?.status === 'Overdue';

            const icon = isComplete ? <CheckCircle2 className="h-6 w-6 text-emerald-500" />
              : isOverdue ? <AlertCircle className="h-6 w-6 text-rose-500" />
              : isPending ? <Clock className="h-6 w-6 text-amber-500" />
              : assignment ? <Circle className="h-6 w-6 text-sky-400" />
              : <Circle className="h-6 w-6 text-slate-200" />;

            return (
              <div key={day} className="flex items-start gap-4">
                <div className="relative z-10 flex h-14 w-14 flex-shrink-0 items-center justify-center rounded-full bg-white">
                  {icon}
                </div>
                <div className="flex-1 pb-2">
                  {assignment ? (
                    <Card className={`cursor-pointer p-4 transition hover:shadow-md ${isComplete ? 'ring-emerald-200' : isOverdue ? 'ring-rose-200' : ''}`} >
                      <div onClick={() => onSelectAssignment(assignment)}>
                        <div className="flex items-start justify-between gap-2">
                          <div className="min-w-0">
                            <p className="text-xs font-medium uppercase tracking-wide text-slate-400">Day {day} · {new Date(assignment.assignment_date).toLocaleDateString()}</p>
                            <h3 className="mt-0.5 text-sm font-semibold text-slate-900">{assignment.title}</h3>
                            {assignment.description && <p className="mt-1 line-clamp-1 text-sm text-slate-500">{assignment.description}</p>}
                          </div>
                          <div className="flex flex-shrink-0 flex-col items-end gap-1.5">
                            {sub ? <Badge className={SUBMISSION_STATUS_STYLES[sub.status]}>{sub.status}</Badge> : <Badge className="bg-slate-100 text-slate-500 ring-slate-500/20">Not Started</Badge>}
                            <ArrowRight className="h-4 w-4 text-slate-300" />
                          </div>
                        </div>
                        {(sub?.score !== null && sub?.score !== undefined) && (
                          <p className="mt-2 text-xs font-medium text-slate-500">Score: {sub.score}/5 · {sub.mentor_feedback ?? 'No feedback yet'}</p>
                        )}
                        {assignment.due_date && !sub && (
                          <p className="mt-2 flex items-center gap-1 text-xs text-slate-400"><Clock className="h-3 w-3" /> Due {new Date(assignment.due_date).toLocaleDateString()}</p>
                        )}
                      </div>
                    </Card>
                  ) : (
                    <div className="flex h-14 items-center">
                      <p className="text-sm text-slate-300">Day {day} — No assignment scheduled</p>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
