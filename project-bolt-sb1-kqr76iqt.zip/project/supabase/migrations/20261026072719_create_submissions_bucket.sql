/*
# Create submissions storage bucket

Creates a private storage bucket for assignment file uploads.
Files are stored with unique generated keys (frontend responsibility) and
kept private — access via signed URLs only.

## Notes
- Bucket is private (not public).
- RLS policies allow anon + authenticated to upload and read, since this is a
  single-tenant demo app with role switching on the client.
*/

INSERT INTO storage.buckets (id, name, public)
VALUES ('submissions', 'submissions', false)
ON CONFLICT (id) DO NOTHING;

DROP POLICY IF EXISTS "anon_upload_submissions" ON storage.objects;
CREATE POLICY "anon_upload_submissions" ON storage.objects
  FOR INSERT TO anon, authenticated
  WITH CHECK (bucket_id = 'submissions');

DROP POLICY IF EXISTS "anon_read_submissions" ON storage.objects;
CREATE POLICY "anon_read_submissions" ON storage.objects
  FOR SELECT TO anon, authenticated
  USING (bucket_id = 'submissions');

DROP POLICY IF EXISTS "anon_delete_submissions" ON storage.objects;
CREATE POLICY "anon_delete_submissions" ON storage.objects
  FOR DELETE TO anon, authenticated
  USING (bucket_id = 'submissions');
