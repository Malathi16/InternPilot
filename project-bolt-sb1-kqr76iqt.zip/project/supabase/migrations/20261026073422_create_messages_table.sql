/*
# Create messages table for mentor-to-intern communication

## Overview
Adds a messages table so mentors and administrators can compose and send
email-style messages to individual interns or broadcast to an entire
department. Interns see messages in an inbox view.

## New Table
- `messages`
  - id (uuid pk)
  - from_role (text: admin / mentor)
  - from_name (text — sender display name)
  - to_intern_id (uuid, nullable — null means broadcast to a department)
  - to_department (text, nullable — used for department-wide broadcasts)
  - subject (text)
  - body (text)
  - priority (text: Low / Medium / High)
  - read_at (timestamptz, nullable — when the intern opened it)
  - created_at (timestamptz)

## Security
- RLS enabled, open to anon + authenticated (single-tenant shared data).
*/

CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  from_role text NOT NULL CHECK (from_role IN ('admin','mentor')),
  from_name text NOT NULL,
  to_intern_id uuid REFERENCES interns(id) ON DELETE CASCADE,
  to_department text,
  subject text NOT NULL,
  body text NOT NULL,
  priority text NOT NULL DEFAULT 'Medium' CHECK (priority IN ('Low','Medium','High')),
  read_at timestamptz,
  created_at timestamptz DEFAULT now(),
  CHECK (to_intern_id IS NOT NULL OR to_department IS NOT NULL)
);

ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON messages TO anon, authenticated;

DROP POLICY IF EXISTS "anon_select_messages" ON messages;
CREATE POLICY "anon_select_messages" ON messages FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_messages" ON messages;
CREATE POLICY "anon_insert_messages" ON messages FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_messages" ON messages;
CREATE POLICY "anon_update_messages" ON messages FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_messages" ON messages;
CREATE POLICY "anon_delete_messages" ON messages FOR DELETE TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_messages_intern ON messages(to_intern_id);
CREATE INDEX IF NOT EXISTS idx_messages_dept ON messages(to_department);
CREATE INDEX IF NOT EXISTS idx_messages_created ON messages(created_at);
