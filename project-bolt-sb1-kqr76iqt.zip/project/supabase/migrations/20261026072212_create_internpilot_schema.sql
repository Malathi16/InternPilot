/*
# InternPilot AI — Core Schema

## Overview
Creates the full data model for the Intern Management and Daily Assignment
Tracking System. Single-tenant demo app (no sign-in screen): policies are
open to anon + authenticated because all data is intentionally shared across
the three simulated roles (admin, mentor, intern) via a client-side role
switcher.

## New Tables
1. `interns` — intern profiles and internship metadata.
2. `assignments` — daily assignments created by admins/mentors.
3. `submissions` — versioned intern submissions per assignment.
4. `audit_log` — record of important changes to interns.

## Columns
### interns
- id (uuid pk), full_name, email, phone, photo_url
- intern_id (text, unique human-readable id), department, role, project
- mentor, supervisor, start_date, end_date
- status (Active / On Hold / Completed / Terminated)
- skills (text[]), learning_goals (text), notes (text)
- is_active (bool, soft-delete flag), created_at

### assignments
- id (uuid pk), title, description, day_number
- instructions, learning_objectives, expected_outcome
- assignment_date, due_date, priority, estimated_time_minutes
- attachment_urls (text[]), permitted_formats (text[]), max_file_size_mb, max_file_count
- evaluation_criteria, rubric, acceptance_criteria
- status (draft / published / archived / cancelled)
- target_type (individual / group / batch), target_intern_ids (uuid[])
- created_at

### submissions
- id (uuid pk), intern_id (fk), assignment_id (fk), version (int)
- file_names (text[]), storage_paths (text[]), repo_url, deployed_url
- notes, status (Not Started / In Progress / Submitted / Under Review /
  Changes Requested / Resubmitted / Approved / Overdue)
- mentor_feedback, score (int), resubmission_reason, submitted_at, created_at

### audit_log
- id (uuid pk), intern_id (fk), action, details, actor, created_at

## Security
- RLS enabled on every table.
- Grants (SELECT/INSERT/UPDATE/DELETE) to anon + authenticated (single-tenant shared data).
- Open policies with USING (true) / WITH CHECK (true) — intentional shared data.

## Notes
- Soft deletion via `is_active = false` on interns to preserve history.
- Submissions are versioned: each resubmission inserts a new row with version+1.
*/

CREATE TABLE IF NOT EXISTS interns (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name text NOT NULL,
  email text NOT NULL,
  phone text,
  photo_url text,
  intern_id text UNIQUE NOT NULL,
  department text NOT NULL,
  role text NOT NULL,
  project text,
  mentor text,
  supervisor text,
  start_date date NOT NULL,
  end_date date,
  status text NOT NULL DEFAULT 'Active'
    CHECK (status IN ('Active','On Hold','Completed','Terminated')),
  skills text[] DEFAULT '{}',
  learning_goals text,
  notes text,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE interns ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON interns TO anon, authenticated;
DROP POLICY IF EXISTS "anon_select_interns" ON interns;
CREATE POLICY "anon_select_interns" ON interns FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_interns" ON interns;
CREATE POLICY "anon_insert_interns" ON interns FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_interns" ON interns;
CREATE POLICY "anon_update_interns" ON interns FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_interns" ON interns;
CREATE POLICY "anon_delete_interns" ON interns FOR DELETE TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  day_number int NOT NULL DEFAULT 1,
  instructions text,
  learning_objectives text,
  expected_outcome text,
  assignment_date date NOT NULL DEFAULT CURRENT_DATE,
  due_date date,
  priority text NOT NULL DEFAULT 'Medium'
    CHECK (priority IN ('Low','Medium','High')),
  estimated_time_minutes int,
  attachment_urls text[] DEFAULT '{}',
  permitted_formats text[] DEFAULT '{"pdf","doc","docx","png","jpg","jpeg","zip","txt","py","js","ts","java","cpp"}',
  max_file_size_mb int NOT NULL DEFAULT 10,
  max_file_count int NOT NULL DEFAULT 5,
  evaluation_criteria text,
  rubric text,
  acceptance_criteria text,
  status text NOT NULL DEFAULT 'published'
    CHECK (status IN ('draft','published','archived','cancelled')),
  target_type text NOT NULL DEFAULT 'individual'
    CHECK (target_type IN ('individual','group','batch')),
  target_intern_ids uuid[] DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE assignments ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON assignments TO anon, authenticated;
DROP POLICY IF EXISTS "anon_select_assignments" ON assignments;
CREATE POLICY "anon_select_assignments" ON assignments FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_assignments" ON assignments;
CREATE POLICY "anon_insert_assignments" ON assignments FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_assignments" ON assignments;
CREATE POLICY "anon_update_assignments" ON assignments FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_assignments" ON assignments;
CREATE POLICY "anon_delete_assignments" ON assignments FOR DELETE TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS submissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  intern_id uuid NOT NULL REFERENCES interns(id) ON DELETE CASCADE,
  assignment_id uuid NOT NULL REFERENCES assignments(id) ON DELETE CASCADE,
  version int NOT NULL DEFAULT 1,
  file_names text[] DEFAULT '{}',
  storage_paths text[] DEFAULT '{}',
  repo_url text,
  deployed_url text,
  notes text,
  status text NOT NULL DEFAULT 'In Progress'
    CHECK (status IN ('Not Started','In Progress','Submitted','Under Review','Changes Requested','Resubmitted','Approved','Overdue')),
  mentor_feedback text,
  score int,
  resubmission_reason text,
  submitted_at timestamptz,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE submissions ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON submissions TO anon, authenticated;
DROP POLICY IF EXISTS "anon_select_submissions" ON submissions;
CREATE POLICY "anon_select_submissions" ON submissions FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_submissions" ON submissions;
CREATE POLICY "anon_insert_submissions" ON submissions FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_submissions" ON submissions;
CREATE POLICY "anon_update_submissions" ON submissions FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_submissions" ON submissions;
CREATE POLICY "anon_delete_submissions" ON submissions FOR DELETE TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS audit_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  intern_id uuid REFERENCES interns(id) ON DELETE CASCADE,
  action text NOT NULL,
  details text,
  actor text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE audit_log ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON audit_log TO anon, authenticated;
DROP POLICY IF EXISTS "anon_select_audit_log" ON audit_log;
CREATE POLICY "anon_select_audit_log" ON audit_log FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_audit_log" ON audit_log;
CREATE POLICY "anon_insert_audit_log" ON audit_log FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_audit_log" ON audit_log;
CREATE POLICY "anon_update_audit_log" ON audit_log FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_audit_log" ON audit_log;
CREATE POLICY "anon_delete_audit_log" ON audit_log FOR DELETE TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_interns_status ON interns(status);
CREATE INDEX IF NOT EXISTS idx_interns_department ON interns(department);
CREATE INDEX IF NOT EXISTS idx_assignments_day ON assignments(day_number);
CREATE INDEX IF NOT EXISTS idx_assignments_status ON assignments(status);
CREATE INDEX IF NOT EXISTS idx_submissions_intern ON submissions(intern_id);
CREATE INDEX IF NOT EXISTS idx_submissions_assignment ON submissions(assignment_id);
CREATE INDEX IF NOT EXISTS idx_audit_intern ON audit_log(intern_id);
